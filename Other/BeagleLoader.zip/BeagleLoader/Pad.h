#pragma once
class Pad
{
public:
	Pad();
	~Pad();

	// Muxes the given pad using the given configuration options
	static bool MuxPad(unsigned int bank, unsigned int pin, unsigned int configuration);
	// Muxes the given pad using the provided configuration flags
	static bool MuxPad(unsigned int bank, unsigned int pin, unsigned int muxmode, bool input, bool fastSlew, bool pullEnable, bool pullUp);

	// Represents the memory addresses of the various GPIO modules
	static const int PadRegisters[4][32];

	// Represents the pad register control module memory addresses, a value of zero indicates the given
	//  pad cannot be used.
	static const int ControlRegisters[4];

	// Gets the pad register configuration value for the given pin properties
	static unsigned int GetPadConfiguration(unsigned int muxmode, bool input, bool fastSlew, bool pullEnable, bool pullUp);
};

