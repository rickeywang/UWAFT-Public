#pragma once
class Updater
{
public:
	Updater();
	~Updater();
	static unsigned char RequestBootMode();
	static void EnterUpdateMode();
	static void ReceiveUpdate();

};

#define BOOT_MODE_UPDATER  1
#define BOOT_MODE_MODEL   2