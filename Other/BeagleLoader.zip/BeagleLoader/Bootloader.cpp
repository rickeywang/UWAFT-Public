#include "Bootloader.h"
#include "Log.h"

#include "bl_copy.h"

Bootloader::Bootloader()
{

}


Bootloader::~Bootloader()
{

}

void Bootloader::Bootload()
{
	ImageCopy();

	Log::Info("Copied model to RAM");
}

void Bootloader::CreateUpdateFile(char* name)
{
	CreateUpdate(name);

	Log::Info("Created Update File");
}

void Bootloader::WriteUpdateChunk(char* chunk)
{

}

void Bootloader::FinishUpdate()
{

}