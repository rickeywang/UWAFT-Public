#pragma once
class Encoder
{
public:
	Encoder();
	~Encoder();

	struct EncoderValues
	{
		signed char Position;
		unsigned int LeftGearPosition;
		unsigned int RightGearPosition;
		char Temperature;
	};

	static EncoderValues Values;
	static bool ISR;
	static void ReadValues();
	static void WritePayloadToModel();
};

static unsigned char greyToBinary(unsigned char grey);
static unsigned char reverseChar(unsigned char byte);