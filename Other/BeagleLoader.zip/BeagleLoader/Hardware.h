#pragma once
class Hardware
{
public:
	Hardware();
	~Hardware();
	
	static const unsigned int UART1BaudRate;

	/// Initializes BeagleBone peripherals, setting GPIO pins directions, creating IRQ masks etc.
	static void Start();
	static void ConfigureHardware();

	static void InitializeGPIO0();
	static void InitializeGPIO1();
	static void InitializeGPIO2();
	static void InitializeGPIO3();

	static void GPIO2ModuleClkConfig();
	static void GPIO3ModuleClkConfig();
	static void UART1ModuleClkConfig();
	static void UART2ModuleClkConfig();
	static void PWMSSModuleClkConfig(unsigned int instanceNum);

	static void SetupBranchPrediction();
	static void SetupFloatingPoint();
	static void SetupMMU();
	static void SetupWatchdogTimer();
	static void SetupProcessorTick(unsigned int clockRateHz, void(*tickHandler)(void));
	
	static void SetupUART1();
	static void SetupUART2();

	static void SetupPWM();
	static void SetupADC();
	static void SetupI2C();

	static void GPIOBank1FunctionalTest();
	static void GPIOBank2FunctionalityTest();

	static void SetPWMDuty(unsigned short duty);

	static void DoESTOP();

};
static void ADCInt();
static void WatchdogFailure()__attribute__((interrupt("IRQ"), naked));

#define ResetTimer(timer)												 \
	/* Clear Match interrupt */											 \
	HWREG(timer + 0x30) = 0x1;											 \
	/* Set the IRQSTATUS register to confirm the IRQ has been handled */ \
	HWREG(timer + 0x28) = 0x1;											 \
	/* Set the IRQ again and carry on with life */						 \
	HWREG(timer + 0x2C) = 0x1;											 \
	/* Reset the timer and claim the interrupt has been handled */		 \
	HWREG(timer + 0x44) = 0xFF;											 \
	HWREG(timer + INTC_CONTROL) = 0x1;


extern int special_counter;
