#include "Pad.h"

#include "beaglebone.h"
#include "soc_AM335x.h"
#include "gpio_v2.h"
#include "hw_cm_per.h"
#include "hw_control_AM335x.h"


Pad::Pad()
{
}


Pad::~Pad()
{
}

bool Pad::MuxPad(unsigned int bank, unsigned int pin, unsigned int configuration)
{
	// If we're not trying to assign a non-accessible bank and pin
	if (bank <= 3 && pin <= 31 && Pad::PadRegisters[bank][pin] != 0)
	{
		GpioPinMuxSetup(Pad::PadRegisters[bank][pin], configuration);
		return true;
	}

	return false;
}

bool Pad::MuxPad(unsigned int bank, unsigned int pin, unsigned int muxmode, bool input, bool fastSlew, bool pullEnable, bool pullUp)
{
	// If we're not trying to assign a non-accessible bank and pin
	if (bank <= 3 && pin <= 31 && Pad::PadRegisters[bank][pin] != 0)
	{
		GpioPinMuxSetup(Pad::PadRegisters[bank][pin], GetPadConfiguration(muxmode, input, fastSlew, pullEnable, pullUp));
		return true;
	}

	return false;
}

unsigned int Pad::GetPadConfiguration(unsigned int muxmode, bool input, bool fastSlew, bool pullEnable, bool pullUp)
{
	unsigned value = muxmode;

	if (input)
		value |= CONTROL_CONF_RXACTIVE;
	if (!fastSlew)
		value |= CONTROL_CONF_SLOWSLEW;
	if (!pullEnable)
		value |= CONTROL_CONF_PULLUDDISABLE;
	if (pullUp)
		value |= CONTROL_CONF_PULLUPSEL;
	
	return value;
}

// Represents the memory addresses of the various GPIO modules
const int Pad::ControlRegisters[4] =
{
	SOC_GPIO_0_REGS,
	SOC_GPIO_1_REGS,
	SOC_GPIO_2_REGS,
	SOC_GPIO_3_REGS
};

// Represents the pad register control module memory addresses, a value of zero indicates the given
//  pad cannot be used.
const int Pad::PadRegisters[4][32] =
{
	// GPIO module 0
	{
		(0x0948),
		(0x094c),
		(0x0950),
		(0x0954),
		(0x0958),
		(0x095c),
		(0x0960),
		(0x0964),
		(0x08d0),
		(0x08d4),
		(0x08d8),
		(0x08dc),
		(0x0978),
		(0x097c),
		(0x0980),
		(0x0984),
		(0x091c),
		(0x0920),
		(0x0a1c),
		(0x09b0),
		(0x09b4),
		(0x0924),
		(0x0820),
		(0x0824),
		0,
		0,
		(0x0828),
		(0x082c),
		(0x0928),
		(0x0944),
		(0x0870),
		(0x0874)
	},

	// GPIO Module 1
	{
		(0x0800),
		(0x0804),
		(0x0808),
		(0x080c),
		(0x0810),
		(0x0814),
		(0x0818),
		(0x081c),
		(0x0968),
		(0x096c),
		(0x0970),
		(0x0974),
		(0x0830),
		(0x0834),
		(0x0838),
		(0x083c),
		(0x0840),
		(0x0844),
		(0x0848),
		(0x084c),
		(0x0850),
		(0x0854),
		(0x0858),
		(0x085c),
		(0x0860),
		(0x0864),
		(0x0868),
		(0x086c),
		(0x0878),
		(0x087c),
		(0x0880),
		(0x0884)
	},

	// GPIO Module 2
	{
		(0x0888),
		(0x088c),
		(0x0890),
		(0x0894),
		(0x0898),
		(0x089c),
		(0x08a0),
		(0x08a4),
		(0x08a8),
		(0x08ac),
		(0x08b0),
		(0x08b4),
		(0x08b8),
		(0x08bc),
		(0x08c0),
		(0x08c4),
		(0x08c8),
		(0x08cc),
		(0x0934),
		(0x0938),
		(0x093c),
		(0x0940),
		(0x08e0),
		(0x08e4),
		(0x08e8),
		(0x08ec),
		(0x08f0),
		(0x08f4),
		(0x08f8),
		(0x08fc),
		(0x0900),
		(0x0904)
	},

	// GPIO Module 3
	{
		(0x0908),
		(0x090c),
		(0x0910),
		(0x0914),
		(0x0918),
		(0x0988),
		(0x098c),
		(0x09e4),
		(0x09e8),
		(0x092c),
		(0x0930),
		0,
		0,
		(0x0a34),
		(0x0990),
		(0x0994),
		(0x0998),
		(0x099c),
		(0x09a0),
		(0x09a4),
		(0x09a8),
		(0x09ac),
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0
	}
};