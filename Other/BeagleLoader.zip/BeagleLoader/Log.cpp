#include <stdio.h>
#include <cstring>

#include "uartStdio.h"
#include "consoleUtils.h"

#include "Log.h"
#include "consoleUtils.h"

Log::OutputLevel Log::currentTraceLevel = Log::TraceLevel;

unsigned int Log::BuildMinorVersion = 9;
unsigned int Log::BuildMajorVersion = 0;

Log::Log()
{
	ConsoleUtilsInit();
}

Log::~Log()
{

}

void Log::Write(Log::OutputLevel level, char* string)
{
	if (level < Log::currentTraceLevel)
		return;

	switch (level)
	{
	case Log::TraceLevel:
		ConsoleUtilsPrintf("[TRACE] %s", string);
		break;
	case Log::InfoLevel:
		ConsoleUtilsPrintf("[INFO] %s", string);
		break;
	case Log::WarningLevel:
		ConsoleUtilsPrintf("[WARNING] %s", string);
		break;
	case Log::ErrorLevel:
		ConsoleUtilsPrintf("[ERROR] %s", string);
		break;
	case Log::FatalLevel:
		ConsoleUtilsPrintf("[FATAL] %s", string);
		break;
	default:
		break;
	}
}
void Log::Write(Log::OutputLevel level, const char* formatString, ...)
{
	if (level < Log::currentTraceLevel)
		return;

	va_list arg;

	/* Start the variable arguments processing. */
	va_start(arg, formatString);

	switch (level)
	{
	case Log::TraceLevel:
		ConsoleUtilsPrintf("[TRACE] ");
		break;
	case Log::InfoLevel:
		ConsoleUtilsPrintf("[INFO] ");
		break;
	case Log::WarningLevel:
		ConsoleUtilsPrintf("[WARNING] ");
		break;
	case Log::ErrorLevel:
		ConsoleUtilsPrintf("[ERROR] ");
		break;
	case Log::FatalLevel:
		ConsoleUtilsPrintf("[FATAL] ");
		break;
	default:
		break;
	}
	UARTPrintf(formatString, arg);
	va_end(arg);
}

void Log::WriteLine(Log::OutputLevel level, char* string)
{
	if (level < Log::currentTraceLevel)
		return;

	switch (level)
	{
	case Log::TraceLevel:
		ConsoleUtilsPrintf("[TRACE] %s\n", string);
		break;
	case Log::InfoLevel:
		ConsoleUtilsPrintf("[INFO] %s\n", string);
		break;
	case Log::WarningLevel:
		ConsoleUtilsPrintf("[WARNING] %s\n", string);
		break;
	case Log::ErrorLevel:
		ConsoleUtilsPrintf("[ERROR] %s\n", string);
		break;
	case Log::FatalLevel:
		ConsoleUtilsPrintf("[FATAL] %s\n", string);
		break;
	default:
		break;
	}
}

void Log::WriteLine(Log::OutputLevel level, const char* formatString, ...)
{
	if (level < Log::currentTraceLevel)
		return;

	va_list arg;

	/* Start the variable arguments processing. */
	va_start(arg, formatString);

	switch (level)
	{
	case Log::TraceLevel:
		ConsoleUtilsPrintf("[TRACE] ");
		break;
	case Log::InfoLevel:
		ConsoleUtilsPrintf("[INFO] ");
		break;
	case Log::WarningLevel:
		ConsoleUtilsPrintf("[WARNING] ");
		break;
	case Log::ErrorLevel:
		ConsoleUtilsPrintf("[ERROR] ");
		break;
	case Log::FatalLevel:
		ConsoleUtilsPrintf("[FATAL] ");
		break;
	default:
		break;
	}
	UARTPrintf(formatString, arg);
	ConsoleUtilsPrintf("\n");
	va_end(arg);
}

void Log::WriteMemory(unsigned int startAddress, unsigned int lengthBytes)
{
	unsigned int* addressPtr;
	Log::Special("MEM", "Dump From: %x", startAddress);


	for (unsigned int i = 0; i < lengthBytes; i++)
	{
		addressPtr = (unsigned int*)startAddress + i;
		Log::Special("MEM", "%x: %x", addressPtr, *addressPtr);
	}
}

void Log::Trace(char* string)
{
	if (Log::TraceLevel < Log::currentTraceLevel)
		return;
	ConsoleUtilsPrintf("[TRACE] %s\n", string);
}

void Log::Trace(const char* formatString, ...)
{
	if (Log::TraceLevel < Log::currentTraceLevel)
		return;

	va_list arg;

	/* Start the variable arguments processing. */
	va_start(arg, formatString);
	ConsoleUtilsPrintf("[TRACE] ");
	UARTPrintf(formatString, arg);
	ConsoleUtilsPrintf("\n");
	va_end(arg);
}

void Log::Info(char* string)
{
	if (Log::InfoLevel < Log::currentTraceLevel)
		return;
	ConsoleUtilsPrintf("[TRACE] %s\n", string);
}

void Log::Info(const char* formatString, ...)
{
	if (Log::InfoLevel < Log::currentTraceLevel)
		return;

	va_list arg;

	/* Start the variable arguments processing. */
	va_start(arg, formatString);
	ConsoleUtilsPrintf("[INFO] ");
	UARTPrintf(formatString, arg);
	ConsoleUtilsPrintf("\n");
	va_end(arg);
}

void Log::Warning(char* string)
{
	if (Log::WarningLevel < Log::currentTraceLevel)
		return;
	ConsoleUtilsPrintf("[WARNING] %s\n", string);
}

void Log::Warning(const char* formatString, ...)
{
	if (Log::WarningLevel < Log::currentTraceLevel)
		return;

	va_list arg;

	/* Start the variable arguments processing. */
	va_start(arg, formatString);
	ConsoleUtilsPrintf("[WARNING] ");
	UARTPrintf(formatString, arg);
	ConsoleUtilsPrintf("\n");
	va_end(arg);
}

void Log::Error(char* string)
{
	if (Log::ErrorLevel < Log::currentTraceLevel)
		return;
	ConsoleUtilsPrintf("[ERROR] %s\n", string);
}

void Log::Error(const char* formatString, ...)
{
	if (Log::ErrorLevel < Log::currentTraceLevel)
		return;

	va_list arg;

	/* Start the variable arguments processing. */
	va_start(arg, formatString);
	ConsoleUtilsPrintf("[ERROR] ");
	UARTPrintf(formatString, arg);
	ConsoleUtilsPrintf("\n");
	va_end(arg);
}

void Log::Fatal(char* string)
{
	if (Log::FatalLevel < Log::currentTraceLevel)
		return;
	ConsoleUtilsPrintf("[FATAL] %s\n", string);
}

void Log::Fatal(const char* formatString, ...)
{
	if (Log::FatalLevel < Log::currentTraceLevel)
		return;

	va_list arg;

	/* Start the variable arguments processing. */
	va_start(arg, formatString);
	ConsoleUtilsPrintf("[FATAL] ");
	UARTPrintf(formatString, arg);
	ConsoleUtilsPrintf("\n");
	va_end(arg);
}

void Log::WriteBootHeader()
{
	ConsoleUtilsPrintf("AutoBike OS [V%u.%u]\n", Log::BuildMajorVersion, Log::BuildMinorVersion);
	ConsoleUtilsPrintf("(c) 2014 Brandon E. Walton for SUTD\n\n");
}

void Log::Special(const char* type, const char* formatString, ...)
{
	ConsoleUtilsPrintf("[");
	ConsoleUtilsPrintf(type);
	ConsoleUtilsPrintf("] ");
	va_list arg;

	/* Start the variable arguments processing. */
	va_start(arg, formatString);
	UARTPrintf(formatString, arg);
	ConsoleUtilsPrintf("\n");
	va_end(arg);
}

void Log::Special(const char* type, char* string)
{
	ConsoleUtilsPrintf("[");
	ConsoleUtilsPrintf(type);
	ConsoleUtilsPrintf("] ");
	ConsoleUtilsPrintf(string);
	ConsoleUtilsPrintf("\n");
}

void Log::SetTraceLevel(Log::OutputLevel level)
{
	Log::currentTraceLevel = level;
}

Log::OutputLevel Log::GetTraceLevel()
{
	return Log::currentTraceLevel;
}