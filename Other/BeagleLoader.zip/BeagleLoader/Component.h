#pragma once

// Represents a unique identifier for each of the pins connected to the beaglebone expansion board,
//  use these values as identifiers for the peripheral drivers (i.e. the GPIO class)
enum class Component : int
{
	// User LED 0 (OUTPUT)
	// Logic High:	LED illuminates
	// Logic Low:	LED does not illuminate
	// Slew Rate:	Fullspeed
	// Pull:		Pull-Down
	// GPIO1[21] (no mux/default)
	LED0,

	// User LED 1 (OUTPUT)
	// Logic High:	LED illuminates
	// Logic Low:	LED does not illuminate
	// Slew Rate:	Fullspeed
	// Pull:		Pull-Down
	// GPIO1[22] (no mux/default)
	LED1,

	// User LED 2 (OUTPUT)
	// Logic High:	LED illuminates
	// Logic Low:	LED does not illuminate
	// Slew Rate:	Fullspeed
	// Pull:		Pull-Down
	// GPIO1[23] (no mux/default)
	LED2,

	// User LED 3 (OUTPUT)
	// Logic High:	LED illuminates
	// Logic Low:	LED does not illuminate
	// Slew Rate:	Fullspeed
	// Pull:		Pull-Down
	// GPIO1[24] (no mux/default)
	LED3,

	// Steering Motor
	// ------------------------------------------------------------------------

	// Steering Enable A (OUTPUT)
	// Logic High:	Enables BTN7960 (DRV4) power
	// Logic Low:	Inhibits BTN7960 (DRV4) power, module enters sleep mode
	// Slew Rate:	Fullspeed
	// Pull:		Pull-Down
	// UART4_CTSN mux @ GPIO0[8] (LCD_DATA12, MODE7)
	SteeringAEnable,

	// Steering Power A (OUTPUT)
	// Logic High:	High side switch activates (12V+ at PWR_SteeringA/HDR3(8))
	// Logic Low:	Low side switch activates (0V at PWR_SteeringA/HDR3(8))
	// Slew Rate:	Fullspeed
	// Pull:		Pull-Down
	// GPIO0[27] (no mux/default)
	SteeringAPower,

	// Steering Enable B (OUTPUT)
	// Logic High:	Enables BTN7960 (DRV1) power
	// Logic Low:	Inhibits BTN7960 (DRV1) power, module enters sleep mode
	// Slew Rate:	Fullspeed
	// Pull:		Pull-Down
	// GPIO2[14] (no mux/default)
	SteeringBEnable,

	// Steering Power B (OUTPUT)
	// Logic High:	High side switch activates (12V+ at PWR_SteeringB/HDR3(7))
	// Logic Low:	Low side switch activates (0V at PWR_SteeringB/HDR3(7))
	// Slew Rate:	Fullspeed
	// Pull:		Pull-Down
	// UART3_CTSN mux @ GPIO2[16] (LCD_DATA10, MODE7)
	SteeringBPower,

	// Steering Current Sense/Error (INPUT/ANALOGUE)
	// Current Sense:	V = I / 6
	SteeringSenseCurrent,

	SteeringSenseI2CClock,
	SteeringSenseI2CData,

	// Right Gear
	// ------------------------------------------------------------------------

	// Right Gear Power 1 (OUTPUT)
	// Logic High:	High side switch activates (12V+ at PWR_RightGearA/HDR3(6) DRV2/BRIDGEB)
	// Logic Low:	Low side switch activates (0V at PWR_RightGearA/HDR3(6) DRV2/BRIDGEB)
	// Logic Supersede: Inhibited by RightGearEnableInput AND RightGearDisable
	// Slew Rate:	Fullspeed
	// Pull:		Pull-Down
	// GPIO2[1] (no mux/default)
	RightGearPower1,

	// Right Gear Power 2 (OUTPUT)
	// Logic High:	High side switch activates (12V+ at PWR_RightGearB/HDR3(9) DRV2/BRIDGEB)
	// Logic Low:	Low side switch activates (0V at PWR_RightGearB/HDR3(9) DRV2/BRIDGEB)
	// Logic Supersede: Inhibited by RightGearEnableInput AND RightGearDisable
	// Slew Rate:	Fullspeed
	// Pull:		Pull-Down
	// GPIO1[15] (no mux/default)
	RightGearPower2,

	// Right Gear Enable Input (OUTPUT)
	// Logic High:	Right Gear Power (DRV2/BRIDGEB) inputs enabled (i.e. react to logic level)
	// Logic Low:	Right Gear Power (DRV2/BRIDGEB) inputs disabled, module enters sleep mode
	// Slew Rate:	Fullspeed
	// Pull:		Pull-Down
	// GPIO2[13] (no mux/default)
	RightGearEnableInput,

	// Right Gear Disable (OUTPUT)
	// Logic High:	Right Gear Power (DRV2/BRIDGEB) outputs (BOTH) tri-stated
	// Logic Low:	Right Gear Power (DRV2/BRIDGEB) outputs (BOTH) normal (According to Power1/2)
	// Description: Logic high tri-states the H-bridge outputs, allowing this pin to PWM control
	//              the H-bridge
	// Slew Rate:	Fullspeed
	// Pull:		Pull-Down
	// GPIO2[12] (no mux/default)
	RightGearDisable,

	// Right Gear Status (INPUT)
	// Logic High:	H-bridge operating normally
	// Logic Low:	RightGearDisable is logic-high OR under-voltage OR over-temperature OR short-circuit
	// Description: This pin is connected to an open-drain pin on the MC33932VW module and is pulled low
	//              when the h-bridge enters a failure mode. Consult the MC33932VW truth table on page 15
	//              for more information.
	// Slew Rate:	Fullspeed
	// Pull:		Pull-Up
	// GPIO2[24] (no mux/default)
	RightGearStatus,

	// Left Gear
	// ------------------------------------------------------------------------

	// Left Gear Power 1 (OUTPUT)
	// Logic High:	High side switch activates (12V+ at PWR_LeftGearA/HDR3(4) DRV2/BRIDGEA)
	// Logic Low:	Low side switch activates (0V at PWR_LeftGearA/HDR3(4) DRV2/BRIDGEA)
	// Logic Supersede: Inhibited by LeftGearEnableInput AND LeftGearDisable
	// Slew Rate:	Fullspeed
	// Pull:		Pull-Down
	// GPIO2[23] (no mux/default)
	LeftGearPower1,

	// Left Gear Power 2 (OUTPUT)
	// Logic High:	High side switch activates (12V+ at PWR_LeftGearB/HDR3(5) DRV2/BRIDGEA)
	// Logic Low:	Low side switch activates (0V at PWR_LeftGearB/HDR3(5) DRV2/BRIDGEA)
	// Logic Supersede: Inhibited by LeftGearEnableInput AND RightGearDisable
	// Slew Rate:	Fullspeed
	// Pull:		Pull-Down
	// GPIO2[22] (no mux/default)
	LeftGearPower2,

	// Left Gear Enable Input (OUTPUT)
	// Logic High:	Left Gear Power (DRV2/BRIDGEA) inputs enabled (i.e. react to logic level)
	// Logic Low:	Left Gear Power (DRV2/BRIDGEA) inputs disabled, module enters sleep mode
	// Slew Rate:	Fullspeed
	// Pull:		Pull-Down
	// GPIO2[8] (no mux/default)
	LeftGearEnableInput,

	// Left Gear Disable (OUTPUT)
	// Logic High:	Left Gear Power (DRV2/BRIDGEA) outputs (BOTH) tri-stated
	// Logic Low:	Left Gear Power (DRV2/BRIDGEA) outputs (BOTH) normal (According to Power1/2)
	// Description: Logic high tri-states the H-bridge outputs, allowing this pin to PWM control
	//              the H-bridge
	// Slew Rate:	Fullspeed
	// Pull:		Pull-Down
	// GPIO2[11] (no mux/default)
	LeftGearDisable,

	// Left Gear Status (INPUT)
	// Logic High:	H-bridge operating normally
	// Logic Low:	LeftGearDisable is logic-high OR under-voltage OR over-temperature OR short-circuit
	// Description: This pin is connected to an open-drain pin on the MC33932VW module and is pulled low
	//              when the h-bridge enters a failure mode. Consult the MC33932VW truth table on page 15
	//              for more information.
	// Slew Rate:	Fullspeed
	// Pull:		Pull-Up
	// UART3_RTSN mux @ GPIO2[17] (LCD_DATA11, MODE7)
	LeftGearStatus,

	// Clutch
	// ------------------------------------------------------------------------

	// Clutch Power 1 (OUTPUT)
	// Logic High:	High side switch activates (12V+ at PWR_ClutchA/HDR3(1) DRV5/BRIDGEB)
	// Logic Low:	Low side switch activates (0V at PWR_ClutchA/HDR3(1) DRV5/BRIDGEB)
	// Logic Supersede: Inhibited by ClutchEnableInput AND ClutchDisable
	// Slew Rate:	Fullspeed
	// Pull:		Pull-Down
	// TIMER6 mux @ GPIO2[4]
	ClutchPower1,

	// Clutch Power 2 (OUTPUT)
	// Logic High:	High side switch activates (12V+ at PWR_ClutchB/HDR3(2) DRV5/BRIDGEB)
	// Logic Low:	Low side switch activates (0V at PWR_ClutchB/HDR3(2) DRV5/BRIDGEB)
	// Logic Supersede: Inhibited by ClutchEnableInput AND ClutchDisable
	// Slew Rate:	Fullspeed
	// Pull:		Pull-Down
	// GPIO2[25] (no mux/default)
	ClutchPower2,

	// Clutch Enable Input (OUTPUT)
	// Logic High:	Clutch power (DRV5/BRIDGEB) inputs enabled (i.e. react to logic level)
	// Logic Low:	Clutch power (DRV5/BRIDGEB) inputs disabled, module enters sleep mode
	// Slew Rate:	Fullspeed
	// Pull:		Pull-Down
	// GPIO1[12] (no mux/default)
	ClutchEnableInput,

	// Clutch Disable (OUTPUT)
	// Logic High:	Clutch power (DRV5/BRIDGEB) outputs (BOTH) tri-stated
	// Logic Low:	Clutch power (DRV5/BRIDGEB) outputs (BOTH) normal (According to Power1/2)
	// Description: Logic high tri-states the H-bridge outputs, allowing this pin to PWM control
	//              the H-bridge
	// Slew Rate:	Fullspeed
	// Pull:		Pull-Down
	// EHRPWM2B mux @ GPIO0[23] (GPMC_AD9, MODE7) (mux valid @ EHRPWM2B for PWM of clutch output)
	ClutchDisable,

	// Clutch Status (INPUT)
	// Logic High:	H-bridge operating normally
	// Logic Low:	ClutchDisable is logic-high OR under-voltage OR over-temperature OR short-circuit
	// Description: This pin is connected to an open-drain pin on the MC33932VW module and is pulled low
	//              when the h-bridge enters a failure mode. Consult the MC33932VW truth table on page 15
	//              for more information.
	// Slew Rate:	Fullspeed
	// Pull:		Pull-Up
	// TIMER7 mux @ GPIO2[3] (GPMC_OEN_REN, MODE7)
	ClutchStatus,

	// Brake
	// ------------------------------------------------------------------------

	// Brake Power 1 (OUTPUT)
	// Logic High:	High side switch activates (12V+ at PWR_BrakeA/HDR6(14) DRV5/BRIDGEA)
	// Logic Low:	Low side switch activates (0V at PWR_BrakeA/HDR6(14) DRV5/BRIDGEA)
	// Logic Supersede: Inhibited by BrakeEnableInput AND BrakeDisable
	// Slew Rate:	Fullspeed
	// Pull:		Pull-Down
	// GPIO1[13] (no mux/default)
	BrakePower1,

	// Brake Power 2 (OUTPUT)
	// Logic High:	High side switch activates (12V+ at PWR_BrakeB/HDR6(20) DRV5/BRIDGEA)
	// Logic Low:	Low side switch activates (0V at PWR_BrakeB/HDR6(20) DRV5/BRIDGEA)
	// Logic Supersede: Inhibited by BrakeEnableInput AND BrakeDisable
	// Slew Rate:	Fullspeed
	// Pull:		Pull-Down
	// GPIO0[26] (no mux/default)
	BrakePower2,

	// Brake Enable Input (OUTPUT)
	// Logic High:	Brake power (DRV5/BRIDGEA) inputs enabled (i.e. react to logic level)
	// Logic Low:	Brake power (DRV5/BRIDGEA) inputs disabled, module enters sleep mode
	// Slew Rate:	Fullspeed
	// Pull:		Pull-Down
	// GPIO2[6] (no mux/default)
	BrakeEnableInput,

	// Brake Disable (OUTPUT)
	// Logic High:	Clutch power (DRV5/BRIDGEA) outputs (BOTH) tri-stated
	// Logic Low:	Clutch power (DRV5/BRIDGEA) outputs (BOTH) normal (According to Power1/2)
	// Description: Logic high tri-states the H-bridge outputs, allowing this pin to PWM control
	//              the H-bridge
	// Slew Rate:	Fullspeed
	// Pull:		Pull-Down
	// GPIO2[9] (no mux/default)
	BrakeDisable,

	// Brake Status (INPUT)
	// Logic High:	H-bridge operating normally
	// Logic Low:	ClutchDisable is logic-high OR under-voltage OR over-temperature OR short-circuit
	// Description: This pin is connected to an open-drain pin on the MC33932VW module and is pulled low
	//              when the h-bridge enters a failure mode. Consult the MC33932VW truth table on page 15
	//              for more information.
	// Slew Rate:	Fullspeed
	// Pull:		Pull-Up
	// GPIO1[14]
	BrakeStatus,

	UART2RX,

	UART2TX,
	
	WheelSpeedPulse,
};