#include "soc_AM335x.h"
#include "beaglebone.h"
#include "gpio_v2.h"

#include "Log.h"
#include "Hardware.h"
#include "UART.h"
#include "Bootloader.h"
#include "Updater.h"

#include "hw_control_AM335x.h"
#include "pin_mux.h"
#include "uart_irda_cir.h"

#include <stdlib.h>

static bool receivingUpdate = false;

Updater::Updater() {

}

Updater::~Updater() {

}

unsigned char Updater::RequestBootMode() {
	UART::WriteCommand((signed char) CMD_ID_REQUEST_BOOT, 0, 0, false);

	//try to put a bit of delay between subsequent requests
	int i = 0;
	while ((i++) < 20000000) {
		__asm volatile("NOP");
	}

	int* response = UART::ReadPayloadBuffer();
	if (response[CMD_ID] == CMD_ID_REQUEST_BOOT) {
		if (response[SUB_ID] == RSP_BOOT_UPDATE) {
			return BOOT_MODE_UPDATER;
		} else {
			return BOOT_MODE_MODEL;
		}
	}
	return 0;
}

void Updater::EnterUpdateMode() {
	while(UART::readBuffer[CMD_ID] != CMD_ID_FMWR_UPDATE)
		UART::ReadCommand();

	signed char type = UART::readBuffer[SUB_ID];

	if (type == UPDATE_FIRMWARE) {
		UART::DebugWrite("BEK receiving update to firmware");
	} else {
		UART::DebugWrite("BEK receiving update to model");
	}

	
	Log::Trace("Trying to create test file");
	Bootloader::CreateUpdateFile("/test");

	//ReceiveUpdate();
}

void Updater::ReceiveUpdate() {
	receivingUpdate = true;
	int count = 0;
	int failTheshold = 1000000;
	while (receivingUpdate && count < failTheshold) {
		UART::ReadCommand();
		if (UART::readBuffer[CMD_ID] == CMD_ID_FMWR_UPDATE) {
			if (UART::readBuffer[SUB_ID] == UPDATE_DONE) {
				receivingUpdate = false;
			}
		}
		count ++;
	}

	if (count > failTheshold) {
		UART::DebugWrite("Failed to Finish Receiving");
	} else {
		UART::DebugWrite("Finished Receiving Update");
	}
}


