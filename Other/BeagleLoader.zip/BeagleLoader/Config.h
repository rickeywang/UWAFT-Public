#pragma once

#include "soc_AM335x.h"
#include "gpio_v2.h"
#include "hw_control_AM335x.h"
#include "pin_mux.h"




//#define COMP_SteeringAEnable_BANK			SOC_GPIO_0_REGS
//#define COMP_SteeringAEnable_DIR			GPIO_DIR_OUTPUT
//#define COMP_SteeringAEnable_GPIOINSTANCE	0
//#define COMP_SteeringAEnable_PIN			8
//#define COMP_SteeringAEnable_PADMODE		7
//#define COMP_SteeringAEnable_PAD			PAD_FS_RXD_PD_PUPDE(COMP_SteeringAEnable_PADMODE)
//
//
//// Right Gear Enable (OUTPUT)
//// Logic High:	Enables MC33932VW (DRV2/BRIDGEA) power (i.e. accepts logic inputs)
//// Logic Low:	Inhibits MC33932VW (DRV2/BRIDGEA) power, module enters sleep mode
//// Slew Rate:	Fullspeed
//// Pull:		Pull-Down
//// GPIO2[13] mux @ GPIO2[13] (LCD_DATA7, MODE7)
//#define COMP_RightGearEnable_BANK			SOC_GPIO_2_REGS
//#define COMP_RightGearEnable_DIR			GPIO_DIR_OUTPUT
//#define COMP_RightGearEnable_GPIOINSTANCE	2
//#define COMP_RightGearEnable_PIN			13
//#define COMP_RightGearEnable_PADMODE		7
//#define COMP_RightGearEnable_PAD			PAD_FS_RXD_PD_PUPDE(COMP_RightGearEnable_PADMODE)
//
//// Right Gear Power 1 (OUTPUT)
//// Logic High:	Enables MC33932VW (DRV2/BRIDGEA)  power
//// Logic Low:	Inhibits MC33932VW (DRV2/BRIDGEA) power, module enters sleep mode
//// Slew Rate:	Fullspeed
//// Pull:		Pull-Down
//// GPIO2[13] mux @ GPIO2[13] (LCD_DATA12, MODE7)
//#define COMP__BANK			SOC_GPIO_0_REGS
//#define COMP__DIR			GPIO_DIR_OUTPUT
//#define COMP__GPIOINSTANCE	0
//#define COMP__PIN			8
//#define COMP__PADMODE		7
//#define COMP__PAD			PAD_FS_RXD_PD_PUPDE(COMP__PADMODE)

// Configures a given GPIO pin for use according to the defined COMP_ definitions
//#define ConfigureGPIO(component) GPIO_PMUX_OFFADDR_VALUE(COMP_##component##_GPIOINSTANCE, COMP_##component##_PIN, COMP_##component##_PAD);
//#define SetOutput(component, outputEnable) GPIOPinWrite(COMP_##component##_BANK, COMP_##component##_PIN, outputEnable)