#pragma once
#include "Component.h"

#include "hw_intc.h"
#include "dmtimer.h"

class GPIO
{
public:
	GPIO();
	~GPIO();

	static const int PadRegisters[4][32];
	static const int GPIOControlRegisters[4];

	static const int AssignmentCount = 64;

	struct GPIOAssignment
	{
		bool Used;

		Component Identifier;

		int Bank;
		int Pin;
		int PadConfiguration;
	};

	static GPIOAssignment Assignments[AssignmentCount];

	static void AssignPin(Component identifier, int bank, int pin, int padConfiguration);
	static void Set(Component identifier, bool value);
	static void RegisterInterrupt(int bank, int pin, int eventType);

};