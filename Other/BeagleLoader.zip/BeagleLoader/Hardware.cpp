#include "Hardware.h"
#include "Log.h"
#include "GPIO.h"
#include "Component.h"
#include "ADC.h"
#include "I2C.h"
#include "beaglebone.h"
#include "soc_AM335x.h"
#include "hw_control_AM335x.h"
#include "hw_cm_wkup.h"
#include "hw_cm_per.h"
#include "hw_types.h"
#include "hw_cm_dpll.h"

#include "watchdog.h"
#include "gpio_v2.h"
#include "uart_irda_cir.h"
#include "ehrpwm.h"
#include "tsc_adc.h"
#include "mmu.h"
#include "cache.h"
#include "cp15.h"
#include "interrupt.h"
#include "dmtimer.h"
#include "pin_mux.h"


#define CLOCK_DIV_VAL                 (10)
#define SOC_EHRPWM_2_MODULE_FREQ      (100000000)

#define START_ADDR_DDR             (0x80000000u)
#define START_ADDR_DEV             (0x44000000u)
#define START_ADDR_OCMC            (0x40300000u)
#define NUM_SECTIONS_DDR           (512u)
#define NUM_SECTIONS_DEV           (960u)
#define NUM_SECTIONS_OCMC          (1u)

#define Timer2ClockRate 24000000 /* 24 MHz*/

static volatile unsigned int pageTable[MMU_PAGETABLE_NUM_ENTRY]
__attribute__((aligned(MMU_PAGETABLE_ALIGN_SIZE)));

Hardware::Hardware()
{
}

Hardware::~Hardware()
{
}

const unsigned int Hardware::UART1BaudRate = 115200;
int special_counter = 20;

void Hardware::Start()
{
	Log::Info("Initializing MMU and Caching...");
	SetupMMU();
	CacheEnable(CACHE_ICACHE);
	CacheEnable(CACHE_DCACHE);

	Log::Info("Initializing IRQ system...");
	/* Enable IRQ in CPSR */
	IntMasterIRQEnable();

	/* Initialize the ARM interrupt control */
	IntAINTCInit();

	Log::Info("Initializing periperals...");

	// GPIOs
	InitializeGPIO0();
	InitializeGPIO1();
	InitializeGPIO2();
	InitializeGPIO3();

	SetupUART1();
	SetupUART2();
	//SetPWMDuty(0);
	//SetupPWM();

	SetupADC();

	SetupI2C();

	Log::Info("Peripherals successfully initialized!!");

	//Hardware::SetupWatchdogTimer();
}

void Hardware::InitializeGPIO0()
{
	// GPIO 0
	Log::Trace("Setting GPIO bank 0 module clock configuration");
	GPIO0ModuleClkConfig();

	Log::Trace("Enabling GPIO bank 0");
	GPIOModuleEnable(SOC_GPIO_0_REGS);
	GPIOModuleReset(SOC_GPIO_0_REGS);
}

void Hardware::InitializeGPIO1()
{
	// GPIO 1
	Log::Trace("Setting GPIO1 module clock configuration");
	GPIO1ModuleClkConfig();

	Log::Trace("Setting pin23 mux setup");
	GPIO1Pin23PinMuxSetup();

	Log::Trace("Enabling GPIO bank 1");
	GPIOModuleEnable(SOC_GPIO_1_REGS);
	GPIOModuleReset(SOC_GPIO_1_REGS);

	Log::Trace("Setting User LED GPIO bank 1 directions");
	GPIODirModeSet(SOC_GPIO_1_REGS, 21, GPIO_DIR_OUTPUT);
	GPIODirModeSet(SOC_GPIO_1_REGS, 22, GPIO_DIR_OUTPUT);
	GPIODirModeSet(SOC_GPIO_1_REGS, 23, GPIO_DIR_OUTPUT);
	GPIODirModeSet(SOC_GPIO_1_REGS, 24, GPIO_DIR_OUTPUT);
}

void Hardware::InitializeGPIO2()
{
	// GPIO 2
	Hardware::GPIO2ModuleClkConfig();

	Log::Trace("Enabling GPIO bank 2");
	GPIOModuleEnable(SOC_GPIO_2_REGS);
	GPIOModuleReset(SOC_GPIO_2_REGS);
}

void Hardware::InitializeGPIO3()
{
	// GPIO 3
	Hardware::GPIO3ModuleClkConfig();

	Log::Trace("Enabling GPIO bank 3");
	GPIOModuleEnable(SOC_GPIO_3_REGS);
	GPIOModuleReset(SOC_GPIO_3_REGS);
}


void Hardware::UART1ModuleClkConfig()
{
	/* Writing to MODULEMODE field of CM_WKUP_UART0_CLKCTRL register. */
	HWREG(SOC_CM_PER_REGS + CM_PER_UART1_CLKCTRL) |=
		CM_PER_UART1_CLKCTRL_MODULEMODE_ENABLE;

	/* Waiting for MODULEMODE field to reflect the written value. */
	while (CM_PER_UART1_CLKCTRL_MODULEMODE_ENABLE !=
		(HWREG(SOC_CM_PER_REGS + CM_PER_UART1_CLKCTRL) &
		CM_PER_UART1_CLKCTRL_MODULEMODE));

	/*
	** Waiting for CLKACTIVITY_UART0_GFCLK field in CM_WKUP_CLKSTCTRL
	** register to attain desired value.
	*/
	while (CM_PER_L4LS_CLKSTCTRL_CLKACTIVITY_UART_GFCLK !=
		(HWREG(SOC_CM_PER_REGS + CM_WKUP_CLKSTCTRL) &
		CM_PER_L4LS_CLKSTCTRL_CLKACTIVITY_UART_GFCLK));
	
	/*
	** Waiting for IDLEST field in CM_WKUP_UART0_CLKCTRL register to attain
	** desired value.
	*/
	while ((CM_PER_UART1_CLKCTRL_IDLEST_FUNC <<
		CM_PER_UART1_CLKCTRL_IDLEST_SHIFT) !=
		(HWREG(SOC_CM_PER_REGS + CM_PER_UART1_CLKCTRL) &
		CM_PER_UART1_CLKCTRL_IDLEST));
}


void Hardware::UART2ModuleClkConfig() {
	HWREG(SOC_CM_PER_REGS + CM_PER_UART2_CLKCTRL) |=
		CM_PER_UART2_CLKCTRL_MODULEMODE_ENABLE;

	/* Waiting for MODULEMODE field to reflect the written value. */
	while (CM_PER_UART2_CLKCTRL_MODULEMODE_ENABLE !=
		(HWREG(SOC_CM_PER_REGS + CM_PER_UART2_CLKCTRL) &
		CM_PER_UART2_CLKCTRL_MODULEMODE));

	/*
	** Waiting for CLKACTIVITY_UART0_GFCLK field in CM_WKUP_CLKSTCTRL
	** register to attain desired value.
	*/
	while (CM_PER_L4LS_CLKSTCTRL_CLKACTIVITY_UART_GFCLK !=
		(HWREG(SOC_CM_PER_REGS + CM_WKUP_CLKSTCTRL) &
		CM_PER_L4LS_CLKSTCTRL_CLKACTIVITY_UART_GFCLK));
	
	/*
	** Waiting for IDLEST field in CM_WKUP_UART0_CLKCTRL register to attain
	** desired value.
	*/
	while ((CM_PER_UART2_CLKCTRL_IDLEST_FUNC <<
		CM_PER_UART2_CLKCTRL_IDLEST_SHIFT) !=
		(HWREG(SOC_CM_PER_REGS + CM_PER_UART2_CLKCTRL) &
		CM_PER_UART2_CLKCTRL_IDLEST));
}

void Hardware::GPIO2ModuleClkConfig()
{
	/* Writing to MODULEMODE field of CM_PER_GPIO2_CLKCTRL register. */
	HWREG(SOC_CM_PER_REGS + CM_PER_GPIO2_CLKCTRL) |=
		CM_PER_GPIO2_CLKCTRL_MODULEMODE_ENABLE;

	/* Waiting for MODULEMODE field to reflect the written value. */
	while (CM_PER_GPIO2_CLKCTRL_MODULEMODE_ENABLE !=
		(HWREG(SOC_CM_PER_REGS + CM_PER_GPIO2_CLKCTRL) &
		CM_PER_GPIO2_CLKCTRL_MODULEMODE));
	/*
	** Writing to OPTFCLKEN_GPIO_1_GDBCLK bit in CM_PER_GPIO2_CLKCTRL
	** register.
	*/
	HWREG(SOC_CM_PER_REGS + CM_PER_GPIO2_CLKCTRL) |=
		CM_PER_GPIO2_CLKCTRL_OPTFCLKEN_GPIO_2_GDBCLK;

	/*
	** Waiting for OPTFCLKEN_GPIO_1_GDBCLK bit to reflect the desired
	** value.
	*/
	while (CM_PER_GPIO2_CLKCTRL_OPTFCLKEN_GPIO_2_GDBCLK !=
		(HWREG(SOC_CM_PER_REGS + CM_PER_GPIO2_CLKCTRL) &
		CM_PER_GPIO2_CLKCTRL_OPTFCLKEN_GPIO_2_GDBCLK));

	/*
	** Waiting for IDLEST field in CM_PER_GPIO2_CLKCTRL register to attain the
	** desired value.
	*/
	while ((CM_PER_GPIO2_CLKCTRL_IDLEST_FUNC <<
		CM_PER_GPIO2_CLKCTRL_IDLEST_SHIFT) !=
		(HWREG(SOC_CM_PER_REGS + CM_PER_GPIO2_CLKCTRL) &
		CM_PER_GPIO2_CLKCTRL_IDLEST));

	/*
	** Waiting for CLKACTIVITY_GPIO_1_GDBCLK bit in CM_PER_L4LS_CLKSTCTRL
	** register to attain desired value.
	*/
	while (CM_PER_L4LS_CLKSTCTRL_CLKACTIVITY_GPIO_2_GDBCLK !=
		(HWREG(SOC_CM_PER_REGS + CM_PER_L4LS_CLKSTCTRL) &
		CM_PER_L4LS_CLKSTCTRL_CLKACTIVITY_GPIO_2_GDBCLK));
}

void Hardware::GPIO3ModuleClkConfig()
{
	/* Writing to MODULEMODE field of CM_PER_GPIO3_CLKCTRL register. */
	HWREG(SOC_CM_PER_REGS + CM_PER_GPIO3_CLKCTRL) |=
		CM_PER_GPIO3_CLKCTRL_MODULEMODE_ENABLE;

	/* Waiting for MODULEMODE field to reflect the written value. */
	while (CM_PER_GPIO3_CLKCTRL_MODULEMODE_ENABLE !=
		(HWREG(SOC_CM_PER_REGS + CM_PER_GPIO3_CLKCTRL) &
		CM_PER_GPIO3_CLKCTRL_MODULEMODE));
	/*
	** Writing to OPTFCLKEN_GPIO_1_GDBCLK bit in CM_PER_GPIO3_CLKCTRL
	** register.
	*/
	HWREG(SOC_CM_PER_REGS + CM_PER_GPIO3_CLKCTRL) |=
		CM_PER_GPIO3_CLKCTRL_OPTFCLKEN_GPIO_3_GDBCLK;

	/*
	** Waiting for OPTFCLKEN_GPIO_1_GDBCLK bit to reflect the desired
	** value.
	*/
	while (CM_PER_GPIO3_CLKCTRL_OPTFCLKEN_GPIO_3_GDBCLK !=
		(HWREG(SOC_CM_PER_REGS + CM_PER_GPIO3_CLKCTRL) &
		CM_PER_GPIO3_CLKCTRL_OPTFCLKEN_GPIO_3_GDBCLK));

	/*
	** Waiting for IDLEST field in CM_PER_GPIO3_CLKCTRL register to attain the
	** desired value.
	*/
	while ((CM_PER_GPIO3_CLKCTRL_IDLEST_FUNC <<
		CM_PER_GPIO3_CLKCTRL_IDLEST_SHIFT) !=
		(HWREG(SOC_CM_PER_REGS + CM_PER_GPIO3_CLKCTRL) &
		CM_PER_GPIO3_CLKCTRL_IDLEST));

	/*
	** Waiting for CLKACTIVITY_GPIO_1_GDBCLK bit in CM_PER_L4LS_CLKSTCTRL
	** register to attain desired value.
	*/
	while (CM_PER_L4LS_CLKSTCTRL_CLKACTIVITY_GPIO_3_GDBCLK !=
		(HWREG(SOC_CM_PER_REGS + CM_PER_L4LS_CLKSTCTRL) &
		CM_PER_L4LS_CLKSTCTRL_CLKACTIVITY_GPIO_3_GDBCLK));
}

void Hardware::PWMSSModuleClkConfig(unsigned int instanceNum)
{
	HWREG(SOC_PRCM_REGS + CM_PER_L3S_CLKSTCTRL) |=
		CM_PER_L3S_CLKSTCTRL_CLKTRCTRL_SW_WKUP;

	while ((HWREG(SOC_PRCM_REGS + CM_PER_L3S_CLKSTCTRL) &
		CM_PER_L3S_CLKSTCTRL_CLKTRCTRL) != CM_PER_L3S_CLKSTCTRL_CLKTRCTRL_SW_WKUP);

	HWREG(SOC_PRCM_REGS + CM_PER_L3_CLKSTCTRL) |=
		CM_PER_L3_CLKSTCTRL_CLKTRCTRL_SW_WKUP;

	while ((HWREG(SOC_PRCM_REGS + CM_PER_L3_CLKSTCTRL) &
		CM_PER_L3_CLKSTCTRL_CLKTRCTRL) != CM_PER_L3_CLKSTCTRL_CLKTRCTRL_SW_WKUP);

	HWREG(SOC_PRCM_REGS + CM_PER_L3_INSTR_CLKCTRL) |=
		CM_PER_L3_INSTR_CLKCTRL_MODULEMODE_ENABLE;

	while ((HWREG(SOC_PRCM_REGS + CM_PER_L3_INSTR_CLKCTRL) &
		CM_PER_L3_INSTR_CLKCTRL_MODULEMODE) !=
		CM_PER_L3_INSTR_CLKCTRL_MODULEMODE_ENABLE);

	HWREG(SOC_PRCM_REGS + CM_PER_L3_CLKCTRL) |=
		CM_PER_L3_CLKCTRL_MODULEMODE_ENABLE;

	while ((HWREG(SOC_PRCM_REGS + CM_PER_L3_CLKCTRL) &
		CM_PER_L3_CLKCTRL_MODULEMODE) != CM_PER_L3_CLKCTRL_MODULEMODE_ENABLE);

	HWREG(SOC_PRCM_REGS + CM_PER_OCPWP_L3_CLKSTCTRL) |=
		CM_PER_OCPWP_L3_CLKSTCTRL_CLKTRCTRL_SW_WKUP;

	while ((HWREG(SOC_PRCM_REGS + CM_PER_OCPWP_L3_CLKSTCTRL) &
		CM_PER_OCPWP_L3_CLKSTCTRL_CLKTRCTRL) !=
		CM_PER_OCPWP_L3_CLKSTCTRL_CLKTRCTRL_SW_WKUP);

	HWREG(SOC_PRCM_REGS + CM_PER_L4LS_CLKSTCTRL) |=
		CM_PER_L4LS_CLKSTCTRL_CLKTRCTRL_SW_WKUP;

	while ((HWREG(SOC_PRCM_REGS + CM_PER_L4LS_CLKSTCTRL) &
		CM_PER_L4LS_CLKSTCTRL_CLKTRCTRL) !=
		CM_PER_L4LS_CLKSTCTRL_CLKTRCTRL_SW_WKUP);

	HWREG(SOC_PRCM_REGS + CM_PER_L4LS_CLKCTRL) |=
		CM_PER_L4LS_CLKCTRL_MODULEMODE_ENABLE;

	while ((HWREG(SOC_PRCM_REGS + CM_PER_L4LS_CLKCTRL) &
		CM_PER_L4LS_CLKCTRL_MODULEMODE) != CM_PER_L4LS_CLKCTRL_MODULEMODE_ENABLE);

	if (0 == instanceNum)
	{
		HWREG(SOC_PRCM_REGS + CM_PER_EPWMSS0_CLKCTRL) |=
			CM_PER_EPWMSS0_CLKCTRL_MODULEMODE_ENABLE;

		while (CM_PER_EPWMSS0_CLKCTRL_MODULEMODE_ENABLE !=
			(HWREG(SOC_PRCM_REGS + CM_PER_EPWMSS0_CLKCTRL) &
			CM_PER_EPWMSS0_CLKCTRL_MODULEMODE));

		while ((CM_PER_EPWMSS0_CLKCTRL_IDLEST_FUNC <<
			CM_PER_EPWMSS0_CLKCTRL_IDLEST_SHIFT) !=
			(HWREG(SOC_PRCM_REGS + CM_PER_EPWMSS0_CLKCTRL) &
			CM_PER_EPWMSS0_CLKCTRL_IDLEST));

	}
	else if (1 == instanceNum)
	{
		HWREG(SOC_PRCM_REGS + CM_PER_EPWMSS1_CLKCTRL) |=
			CM_PER_EPWMSS1_CLKCTRL_MODULEMODE_ENABLE;

		while (CM_PER_EPWMSS1_CLKCTRL_MODULEMODE_ENABLE !=
			(HWREG(SOC_PRCM_REGS + CM_PER_EPWMSS1_CLKCTRL) &
			CM_PER_EPWMSS1_CLKCTRL_MODULEMODE));

		while ((CM_PER_EPWMSS1_CLKCTRL_IDLEST_FUNC <<
			CM_PER_EPWMSS1_CLKCTRL_IDLEST_SHIFT) !=
			(HWREG(SOC_PRCM_REGS + CM_PER_EPWMSS1_CLKCTRL) &
			CM_PER_EPWMSS1_CLKCTRL_IDLEST));

	}
	else if (2 == instanceNum)
	{
		HWREG(SOC_PRCM_REGS + CM_PER_EPWMSS2_CLKCTRL) |=
			CM_PER_EPWMSS2_CLKCTRL_MODULEMODE_ENABLE;

		while (CM_PER_EPWMSS2_CLKCTRL_MODULEMODE_ENABLE !=
			(HWREG(SOC_PRCM_REGS + CM_PER_EPWMSS2_CLKCTRL) &
			CM_PER_EPWMSS2_CLKCTRL_MODULEMODE));

		while ((CM_PER_EPWMSS2_CLKCTRL_IDLEST_FUNC <<
			CM_PER_EPWMSS2_CLKCTRL_IDLEST_SHIFT) !=
			(HWREG(SOC_PRCM_REGS + CM_PER_EPWMSS2_CLKCTRL) &
			CM_PER_EPWMSS2_CLKCTRL_IDLEST));
	}
	else
	{

	}

	while (!(HWREG(SOC_PRCM_REGS + CM_PER_L3S_CLKSTCTRL) &
		CM_PER_L3S_CLKSTCTRL_CLKACTIVITY_L3S_GCLK));

	while (!(HWREG(SOC_PRCM_REGS + CM_PER_L3_CLKSTCTRL) &
		CM_PER_L3_CLKSTCTRL_CLKACTIVITY_L3_GCLK));

	while (!(HWREG(SOC_PRCM_REGS + CM_PER_OCPWP_L3_CLKSTCTRL) &
		(CM_PER_OCPWP_L3_CLKSTCTRL_CLKACTIVITY_OCPWP_L3_GCLK |
		CM_PER_OCPWP_L3_CLKSTCTRL_CLKACTIVITY_OCPWP_L4_GCLK)));

	while (!(HWREG(SOC_PRCM_REGS + CM_PER_L4LS_CLKSTCTRL) &
		(CM_PER_L4LS_CLKSTCTRL_CLKACTIVITY_L4LS_GCLK)));
}


void Hardware::SetupProcessorTick(unsigned int clockRateHz, void(tickHandler)(void))
{
	DMTimer2ModuleClkConfig();

	/* Registering DMTimerIsr */
	IntRegister(SYS_INT_TINT2, tickHandler);

	/* Set the priority */
	IntPrioritySet(SYS_INT_TINT2, 0, AINTC_HOSTINT_ROUTE_IRQ);

	/* Enable the system interrupt */
	IntSystemEnable(SYS_INT_TINT2);


	///* Start the DMTimer */
	Log::Trace("Resetting DMTIMER2 interface");
	HWREG(0x48040000 + DMTIMER_TIOCP_CFG) = 0x2; // reset interface

	Log::Trace("Initializing DMTIMER2 counter value @ %u", 0);
	HWREG(0x48040000 + DMTIMER_TCRR) = 0; // initialize counter
	Log::Trace("Resetting DMTIMER2 match value @ %u", Timer2ClockRate / clockRateHz);
	HWREG(0x48040000 + DMTIMER_TMAR) = Timer2ClockRate / clockRateHz; // load match value
	Log::Trace("Clearing pending DMTIMER2 interrupts");
	HWREG(0x48040000 + 0x30) = 0x1;

	Log::Trace("Enabling DMTIMER2 match interrupts");
	HWREG(0x48040000 + 0x2C) = 0x1;

	Log::Trace("Setting DMTIMER2 control register to auto-reload with compare");
	HWREG(0x48040000 + 0x38) = 0x43;
	HWREG(0x48040000 + 0x40) = 0x0;

	/* Reset the timer */
	Log::Trace("Resetting timer");
	HWREG(0x48040000 + 0x44) = 0xFF;

}

void Hardware::SetupBranchPrediction()
{
	// Instruct the processor to use branch prediction
	__asm volatile(
	"MOV r0, #0 \n\t"
	"MCR p15, #0, r0, c7, c5, #6 \n\t"
	"ISB \n\t"
	"MRC p15, #0, r0, c1, c0, #0 \n\t"
	"ORR r0, r0, #0x00000800 \n\t"
	"MCR p15, #0, r0, c1, c0, #0 \n\t");
}

void Hardware::SetupFloatingPoint()
{
	#ifdef NEONVFP
	// Start the NEON/VFP engine
	__asm volatile(
	"MRC p15, #0, r1, c1, c0, #2           @ r1 = Access Control Register\n\t"
	"ORR r1, r1, #(0xf << 20)              @ enable full access for p10,11\n\t"
	"MCR p15, #0, r1, c1, c0, #2           @ Access Control Register = r1\n\t"
	"MOV r1, #0\n\t"
	"MCR p15, #0, r1, c7, c5, #4           @flush prefetch buffer\n\t"
	"MOV r0,#0x40000000\n\t"
	"FMXR FPEXC, r0                        @ Set Neon/VFP Enable bit\n\t");
	#endif
}

void Hardware::SetupMMU()
{
    /*
    ** Define DDR memory region of AM335x. DDR can be configured as Normal
    ** memory with R/W access in user/privileged modes. The cache attributes
    ** specified here are,
    ** Inner - Write through, No Write Allocate
    ** Outer - Write Back, Write Allocate
    */
    REGION regionDdr = {
                        MMU_PGTYPE_SECTION, START_ADDR_DDR, NUM_SECTIONS_DDR,
                        MMU_MEMTYPE_NORMAL_NON_SHAREABLE(MMU_CACHE_WT_NOWA,
                                                         MMU_CACHE_WB_WA),
                        MMU_REGION_NON_SECURE, MMU_AP_PRV_RW_USR_RW,
                        (unsigned int*)pageTable
                       };
    /*
    ** Define OCMC RAM region of AM335x. Same Attributes of DDR region given.
    */
    REGION regionOcmc = {
                         MMU_PGTYPE_SECTION, START_ADDR_OCMC, NUM_SECTIONS_OCMC,
                         MMU_MEMTYPE_NORMAL_NON_SHAREABLE(MMU_CACHE_WT_NOWA,
                                                          MMU_CACHE_WB_WA),
                         MMU_REGION_NON_SECURE, MMU_AP_PRV_RW_USR_RW,
                         (unsigned int*)pageTable
                        };

    /*
    ** Define Device Memory Region. The region between OCMC and DDR is
    ** configured as device memory, with R/W access in user/privileged modes.
    ** Also, the region is marked 'Execute Never'.
    */
    REGION regionDev = {
                        MMU_PGTYPE_SECTION, START_ADDR_DEV, NUM_SECTIONS_DEV,
                        MMU_MEMTYPE_DEVICE_SHAREABLE,
                        MMU_REGION_NON_SECURE,
                        MMU_AP_PRV_RW_USR_RW  | MMU_SECTION_EXEC_NEVER,
                        (unsigned int*)pageTable
                       };

    /* Initialize the page table and MMU */
    MMUInit((unsigned int*)pageTable);

    /* Map the defined regions */
    MMUMemRegionMap(&regionDdr);
    MMUMemRegionMap(&regionOcmc);
    MMUMemRegionMap(&regionDev);

    /* Now Safe to enable MMU */
    MMUEnable((unsigned int*)pageTable);
}

void Hardware::SetupWatchdogTimer()
{
	/* Reset the Watchdog Timer */
	WatchdogTimerReset(SOC_WDT_1_REGS);

	/* Disable the Watchdog timer */
	WatchdogTimerDisable(SOC_WDT_1_REGS);

	WatchdogTimerIntEnable(SOC_WDT_1_REGS, 1);

	/* Configure and enable the pre-scaler clock */
	WatchdogTimerPreScalerClkEnable(SOC_WDT_1_REGS, WDT_PRESCALER_CLK_DIV_1);

	/* Set the count value into the counter register */
	WatchdogTimerCounterSet(SOC_WDT_1_REGS, 0xFFFE0000u);

	/* Set the reload value into the load register */
	WatchdogTimerReloadSet(SOC_WDT_1_REGS, 0xFFFF0000u);

	/* Enable the Watchdog Timer */
	WatchdogTimerEnable(SOC_WDT_1_REGS);

	//IRQ::RegisterIRQ(91, 0, WatchdogFailure);
}

void Hardware::SetupUART1()
{
	// UART 1
	Log::Trace("Setting up UART1 @ %u baud", Hardware::UART1BaudRate);
	Hardware::UART1ModuleClkConfig();
	/* RXD */
	HWREG(SOC_CONTROL_REGS + CONTROL_CONF_UART_RXD(1)) =
		(CONTROL_CONF_UART1_RXD_CONF_UART1_RXD_PUTYPESEL |
		CONTROL_CONF_UART1_RXD_CONF_UART1_RXD_RXACTIVE);

	/* TXD */
	HWREG(SOC_CONTROL_REGS + CONTROL_CONF_UART_TXD(1)) =
		CONTROL_CONF_UART1_TXD_CONF_UART1_TXD_PUTYPESEL;
	/* Performing a module reset. */
	UARTModuleReset(SOC_UART_1_REGS);

	/* Performing FIFO configurations. */
	unsigned int fifoConfig = 0;

	/* Setting the TX and RX FIFO Trigger levels as 1. No DMA enabled. */
	fifoConfig = UART_FIFO_CONFIG(UART_TRIG_LVL_GRANULARITY_1,
		UART_TRIG_LVL_GRANULARITY_1,
		1,
		1,
		1,
		1,
		UART_DMA_EN_PATH_SCR,
		UART_DMA_MODE_0_ENABLE);

	/* Configuring the FIFO settings. */
	UARTFIFOConfig(SOC_UART_1_REGS, fifoConfig);

	unsigned int divisorValue = 0;

	/* Computing the Divisor Value. */
	divisorValue = UARTDivisorValCompute(48000000,
		Hardware::UART1BaudRate,
		UART16x_OPER_MODE,
		UART_MIR_OVERSAMPLING_RATE_42);

	/* Programming the Divisor Latches. */
	UARTDivisorLatchWrite(SOC_UART_1_REGS, divisorValue);

	/* Switching to Configuration Mode B. */
	UARTRegConfigModeEnable(SOC_UART_1_REGS, UART_REG_CONFIG_MODE_B);

	/* Programming the Line Characteristics. */
	UARTLineCharacConfig(SOC_UART_1_REGS,
		(UART_FRAME_WORD_LENGTH_8 | UART_FRAME_NUM_STB_1),
		UART_PARITY_NONE);

	/* Disabling write access to Divisor Latches. */
	UARTDivisorLatchDisable(SOC_UART_1_REGS);

	/* Disabling Break Control. */
	UARTBreakCtl(SOC_UART_1_REGS, UART_BREAK_COND_DISABLE);

	/* Switching to UART16x operating mode. */
	UARTOperatingModeSelect(SOC_UART_1_REGS, UART16x_OPER_MODE);
}

void Hardware::SetupUART2() {
	Log::Trace("Setting up UART2 @ %u baud", Hardware::UART1BaudRate);
	Hardware::UART2ModuleClkConfig();
	/* RXD */
	//HWREG(SOC_CONTROL_REGS + CONTROL_CONF_UART_RXD(2)) =
	//	(CONTROL_CONF_UART1_RXD_CONF_UART1_RXD_PUTYPESEL |
	//	CONTROL_CONF_UART1_RXD_CONF_UART1_RXD_RXACTIVE);

	/* TXD */
	//HWREG(SOC_CONTROL_REGS + CONTROL_CONF_UART_TXD(2)) =
	//	CONTROL_CONF_UART1_TXD_CONF_UART1_TXD_PUTYPESEL;
	GPIO::AssignPin(Component::UART2RX, 0, 2, PAD_FS_RXE_PD_PUPDE(1));
	GPIO::AssignPin(Component::UART2TX, 0, 3, PAD_FS_RXE_PD_PUPDE(1));

	/* Performing a module reset. */
	UARTModuleReset(SOC_UART_2_REGS);

	/* Performing FIFO configurations. */
	unsigned int fifoConfig = 0;

	/* Setting the TX and RX FIFO Trigger levels as 1. No DMA enabled. */
	fifoConfig = UART_FIFO_CONFIG(UART_TRIG_LVL_GRANULARITY_1,
		UART_TRIG_LVL_GRANULARITY_1,
		1,
		1,
		1,
		1,
		UART_DMA_EN_PATH_SCR,
		UART_DMA_MODE_0_ENABLE);

	/* Configuring the FIFO settings. */
	UARTFIFOConfig(SOC_UART_2_REGS, fifoConfig);

	unsigned int divisorValue = 0;

	/* Computing the Divisor Value. */
	divisorValue = UARTDivisorValCompute(48000000,
		Hardware::UART1BaudRate,
		UART16x_OPER_MODE,
		UART_MIR_OVERSAMPLING_RATE_42);

	/* Programming the Divisor Latches. */
	UARTDivisorLatchWrite(SOC_UART_2_REGS, divisorValue);

	/* Switching to Configuration Mode B. */
	UARTRegConfigModeEnable(SOC_UART_2_REGS, UART_REG_CONFIG_MODE_B);

	/* Programming the Line Characteristics. */
	UARTLineCharacConfig(SOC_UART_2_REGS,
		(UART_FRAME_WORD_LENGTH_8 | UART_FRAME_NUM_STB_1),
		UART_PARITY_NONE);

	/* Disabling write access to Divisor Latches. */
	UARTDivisorLatchDisable(SOC_UART_2_REGS);

	/* Disabling Break Control. */
	UARTBreakCtl(SOC_UART_2_REGS, UART_BREAK_COND_DISABLE);

	/* Switching to UART16x operating mode. */
	UARTOperatingModeSelect(SOC_UART_2_REGS, UART16x_OPER_MODE);
}

void Hardware::SetupPWM()
{
	Log::Trace("Configuring throttle PWM");

	Log::Trace("Setting pin mux for EHRPWM2A & EHRPWM2B");

	Hardware::PWMSSModuleClkConfig(2);

	GpioPinMuxSetup(CONTROL_CONF_GPMC_AD(8), 4);

	/* Enable Clock for EHRPWM in PWM sub system */
	EHRPWMClockEnable(SOC_PWMSS2_REGS);

	/* Enable Timer Base Module Clock in control module */
	//PWMSSTBClkEnable(2);
	HWREG(SOC_CONTROL_REGS + CONTROL_PWMSS_CTRL) |=
		CONTROL_PWMSS_CTRL_PWMSS2_TBCLKEN;

	/* TimeBase configuration */
	/* Configure the clock frequency */
	EHRPWMTimebaseClkConfig(SOC_EPWM_2_REGS,
		SOC_EHRPWM_2_MODULE_FREQ / CLOCK_DIV_VAL,
		SOC_EHRPWM_2_MODULE_FREQ);

	/* Configure the period of the output waveform */
	EHRPWMPWMOpFreqSet(SOC_EPWM_2_REGS,
		SOC_EHRPWM_2_MODULE_FREQ / CLOCK_DIV_VAL,
		(unsigned int)(SOC_EHRPWM_2_MODULE_FREQ / CLOCK_DIV_VAL) / 0xFF,
		(unsigned int)EHRPWM_COUNT_UP,
		(bool)EHRPWM_SHADOW_WRITE_DISABLE);

	/* Disable synchronization*/
	EHRPWMTimebaseSyncDisable(SOC_EPWM_2_REGS);

	/* Disable syncout*/
	EHRPWMSyncOutModeSet(SOC_EPWM_2_REGS, EHRPWM_SYNCOUT_DISABLE);

	/* Configure the emulation behaviour*/
	EHRPWMTBEmulationModeSet(SOC_EPWM_2_REGS, EHRPWM_STOP_AFTER_NEXT_TB_INCREMENT);

	/* Configure Counter compare cub-module */
	/* Load Compare A value */
	EHRPWMLoadCMPA(SOC_EPWM_2_REGS,
		50,
		(bool)EHRPWM_SHADOW_WRITE_DISABLE,
		(unsigned int)EHRPWM_COMPA_NO_LOAD,
		(bool)EHRPWM_CMPCTL_OVERWR_SH_FL);

	/* Load Compare B value */
	EHRPWMLoadCMPB(SOC_EPWM_2_REGS,
		200,
		(bool)EHRPWM_SHADOW_WRITE_DISABLE,
		(unsigned int)EHRPWM_COMPB_NO_LOAD,
		(bool)EHRPWM_CMPCTL_OVERWR_SH_FL);

	/* Configure Action qualifier */
	/* Toggle when CTR = CMPA */
	EHRPWMConfigureAQActionOnA(SOC_EPWM_2_REGS,
		EHRPWM_AQCTLB_ZRO_EPWMXBHIGH,// EHRPWM_AQCTLB_ZRO_DONOTHING,
		EHRPWM_AQCTLB_PRD_DONOTHING,
		EHRPWM_AQCTLB_CAU_EPWMXBLOW,// EHRPWM_AQCTLB_CAU_EPWMXBTOGGLE,
		EHRPWM_AQCTLB_CAD_DONOTHING,
		EHRPWM_AQCTLB_CBU_DONOTHING,
		EHRPWM_AQCTLB_CBD_DONOTHING,
		EHRPWM_AQSFRC_ACTSFB_DONOTHING);

	/* Bypass dead band sub-module */
	EHRPWMDBOutput(SOC_EPWM_2_REGS, EHRPWM_DBCTL_OUT_MODE_BYPASS);

	/* Disable Chopper sub-module */
	EHRPWMChopperDisable(SOC_EPWM_2_REGS);

	/* Disable trip events */
	EHRPWMTZTripEventDisable(SOC_EPWM_2_REGS, (bool)EHRPWM_TZ_ONESHOT);
	EHRPWMTZTripEventDisable(SOC_EPWM_2_REGS, (bool)EHRPWM_TZ_CYCLEBYCYCLE);

	/* Event trigger */
	/* Generate interrupt every 3rd occurance of the event */
	EHRPWMETIntPrescale(SOC_EPWM_2_REGS, EHRPWM_ETPS_INTPRD_THIRDEVENT);
	/* Generate event when CTR = CMPB */
	EHRPWMETIntSourceSelect(SOC_EPWM_2_REGS, EHRPWM_ETSEL_INTSEL_TBCTREQUCMPBINC);

	/* Disable High resolution capability */
	EHRPWMHRDisable(SOC_EPWM_2_REGS);
}

void Hardware::SetPWMDuty(unsigned short duty)
{
	HWREGH(SOC_EPWM_2_REGS + EHRPWM_CMPA) = duty & EHRPWM_CMPA_CMPA;
}

void Hardware::SetupADC()
{
	Log::Trace("In setup ADC");
	IntRegister(SYS_INT_ADC_TSC_GENINT, ADC::ADCInterrupt);
	IntPrioritySet(SYS_INT_ADC_TSC_GENINT, 5, AINTC_HOSTINT_ROUTE_IRQ);
	IntSystemEnable(SYS_INT_ADC_TSC_GENINT);
	Log::Trace("Interrupts registered");

	/* Writing to MODULEMODE field of CM_WKUP_TSC_CLKCTRL register. */
	HWREG(SOC_CM_WKUP_REGS + CM_WKUP_ADC_TSC_CLKCTRL) |=
		CM_WKUP_ADC_TSC_CLKCTRL_MODULEMODE_ENABLE;

	/* Waiting for MODULEMODE field to reflect the written value. */
	while (CM_WKUP_ADC_TSC_CLKCTRL_MODULEMODE_ENABLE !=
		(HWREG(SOC_CM_WKUP_REGS + CM_WKUP_ADC_TSC_CLKCTRL) &
		CM_WKUP_ADC_TSC_CLKCTRL_MODULEMODE));

	/*
	** Waiting for IDLEST field in CM_WKUP_CONTROL_CLKCTRL register to attain
	** desired value.
	*/
	while ((CM_WKUP_CONTROL_CLKCTRL_IDLEST_FUNC <<
		CM_WKUP_CONTROL_CLKCTRL_IDLEST_SHIFT) !=
		(HWREG(SOC_CM_WKUP_REGS + CM_WKUP_CONTROL_CLKCTRL) &
		CM_WKUP_CONTROL_CLKCTRL_IDLEST));

	while (CM_WKUP_CLKSTCTRL_CLKACTIVITY_ADC_FCLK !=
		(HWREG(SOC_CM_WKUP_REGS + CM_WKUP_CLKSTCTRL) &
		CM_WKUP_CLKSTCTRL_CLKACTIVITY_ADC_FCLK));

	/*
	** Waiting for IDLEST field in CM_WKUP_ADC_TSC_CLKCTRL register to attain
	** desired value.
	*/
	while ((CM_WKUP_ADC_TSC_CLKCTRL_IDLEST_FUNC <<
		CM_WKUP_ADC_TSC_CLKCTRL_IDLEST_SHIFT) !=
		(HWREG(SOC_CM_WKUP_REGS + CM_WKUP_ADC_TSC_CLKCTRL) &
		CM_WKUP_ADC_TSC_CLKCTRL_IDLEST));

	Log::Trace("End Grind");
	HWREG(SOC_CONTROL_REGS + CONTROL_CONF_AIN0) = CONTROL_CONF_AIN0_CONF_AIN0_RXACTIVE;
	HWREG(SOC_CONTROL_REGS + CONTROL_CONF_AIN1) = CONTROL_CONF_AIN1_CONF_AIN1_RXACTIVE;
	HWREG(SOC_CONTROL_REGS + CONTROL_CONF_AIN2) = CONTROL_CONF_AIN2_CONF_AIN2_RXACTIVE;
	HWREG(SOC_CONTROL_REGS + CONTROL_CONF_AIN3) = CONTROL_CONF_AIN3_CONF_AIN3_RXACTIVE;
	HWREG(SOC_CONTROL_REGS + CONTROL_CONF_AIN4) = CONTROL_CONF_AIN4_CONF_AIN4_RXACTIVE;
	HWREG(SOC_CONTROL_REGS + CONTROL_CONF_AIN5) = CONTROL_CONF_AIN5_CONF_AIN5_RXACTIVE;
	HWREG(SOC_CONTROL_REGS + CONTROL_CONF_AIN6) = CONTROL_CONF_AIN6_CONF_AIN6_RXACTIVE;
	HWREG(SOC_CONTROL_REGS + CONTROL_CONF_AIN7) = CONTROL_CONF_AIN7_CONF_AIN7_RXACTIVE;
	HWREG(SOC_CONTROL_REGS + CONTROL_CONF_VREFP) = CONTROL_CONF_VREFP_CONF_VREFP_RXACTIVE;
	HWREG(SOC_CONTROL_REGS + CONTROL_CONF_VREFN) = CONTROL_CONF_VREFN_CONF_VREFN_RXACTIVE;

	Log::Trace("ADC Interrupts and pad control regs set");

	/* configures ADC to 3Mhz */
	TSCADCConfigureAFEClock(SOC_ADC_TSC_0_REGS, 24000000, 3000000);
	Log::Trace("Clock configured");

	// Configure the step id
	TSCADCStepIDTagConfig(SOC_ADC_TSC_0_REGS, true);
	TSCADCStepConfigProtectionDisable(SOC_ADC_TSC_0_REGS);

	Log::Trace("Step configured");
	/* Configure step 1 for channel 1(AN0)*/
	int channel = 6;
	/* Configure ADC to Single ended operation mode */
	//TSCADCTSStepOperationModeControl(SOC_ADC_TSC_0_REGS, TSCADC_SINGLE_ENDED_OPER_MODE, channel);

	/* Configure step to select Channel, refernce voltages */
	//TSCADCTSStepConfig(SOC_ADC_TSC_0_REGS, channel, TSCADC_NEGATIVE_REF_VSSA,
	//TSCADC_POSITIVE_INP_CHANNEL1, TSCADC_NEGATIVE_INP_CHANNEL1, TSCADC_POSITIVE_REF_VDDA);
	//TSCADCTSStepAnalogGroundConfig(SOC_ADC_TSC_0_REGS, TSCADC_XNNSW_PIN_OFF, TSCADC_YPNSW_PIN_OFF,
	//TSCADC_YNNSW_PIN_OFF, TSCADC_WPNSW_PIN_OFF, channel);

	//TSCADCTSStepFIFOSelConfig(SOC_ADC_TSC_0_REGS, channel, TSCADC_FIFO_0);
	
	//TSCADCTSStepModeConfig(SOC_ADC_TSC_0_REGS, channel, TSCADC_ONE_SHOT_SOFTWARE_ENABLED | (TSCADC_SIXTEEN_SAMPLES_AVG << 2));

	/* General purpose inputs */
	TSCADCTSModeConfig(SOC_ADC_TSC_0_REGS, TSCADC_GENERAL_PURPOSE_MODE);

	Log::Trace("ADC unit set up");

	/* Enable step 1 */
	//TSCADCConfigureStepEnable(SOC_ADC_TSC_0_REGS, channel + 1, true);
	TSCADCIntStatusClear(SOC_ADC_TSC_0_REGS, 0x7FF);
	TSCADCIntStatusClear(SOC_ADC_TSC_0_REGS, 0x7FF);
	TSCADCIntStatusClear(SOC_ADC_TSC_0_REGS, 0x7FF);

	/* End of sequence interrupt is enable */
	TSCADCEventInterruptEnable(SOC_ADC_TSC_0_REGS, TSCADC_END_OF_SEQUENCE_INT);

	/* Enable the TSC_ADC_SS module*/
	TSCADCModuleStateSet(SOC_ADC_TSC_0_REGS, TSCADC_MODULE_ENABLE);
	//Log::Trace("Enabled");
}

void Hardware::SetupI2C() {
	I2C::Configure();
}

void ADCInt()
{
	volatile unsigned int status;
	volatile unsigned int result;
	float voltage;

	status = TSCADCIntStatus(SOC_ADC_TSC_0_REGS);
	TSCADCIntStatusClear(SOC_ADC_TSC_0_REGS, status);

	if (status & TSCADC_END_OF_SEQUENCE_INT)
	{
		/* Read data from fifo 0 */
		result = TSCADCFIFOADCDataRead(SOC_ADC_TSC_0_REGS, TSCADC_FIFO_0);
	}

	voltage = (1800.0f * result / 2047);

	Log::Trace("ADC Interrupt, %u mV", (unsigned int)(voltage));

	TSCADCConfigureStepEnable(SOC_ADC_TSC_0_REGS, 1, true);
}

void Hardware::DoESTOP()
{
	GPIOModuleReset(SOC_GPIO_0_REGS);
	GPIOModuleReset(SOC_GPIO_1_REGS);
	GPIOModuleReset(SOC_GPIO_2_REGS);
	GPIOModuleReset(SOC_GPIO_3_REGS);

	EHRPWMClockEnable(false);

	Log::Fatal("ESTOP TRIGGERED");
}

void WatchdogFailure()
{
	Log::Fatal("WATCHDOG TIMEOUT.");
	unsigned int val = 0;
	while (true)
	{
		WatchdogTimerTriggerSet(SOC_WDT_1_REGS, val++);
	}
}