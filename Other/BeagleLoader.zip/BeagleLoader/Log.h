#pragma once
class Log
{
public:
	Log();
	~Log();

	enum OutputLevel
	{
		TraceLevel = 0,
		InfoLevel,
		WarningLevel,
		ErrorLevel,
		FatalLevel
	};

	static unsigned int BuildMajorVersion;
	static unsigned int BuildMinorVersion;

	static void SetTraceLevel(Log::OutputLevel level);
	static Log::OutputLevel GetTraceLevel();

	static void Write(Log::OutputLevel level, char* string);
	static void Write(Log::OutputLevel level, const char* formatString, ...);
	static void WriteLine(Log::OutputLevel level, char* string);
	static void WriteLine(Log::OutputLevel level, const char* formatString, ...);

	static void WriteMemory(unsigned int startAddress, unsigned int lengthBytes);

	static void Trace(char* string);
	static void Trace(const char* formatString, ...);

	static void Info(char* string);
	static void Info(const char* formatString, ...);

	static void Warning(char* string);
	static void Warning(const char* formatString, ...);

	static void Error(char* string);
	static void Error(const char* formatString, ...);

	static void Fatal(char* string);
	static void Fatal(const char* formatString, ...);

	static void Special(const char* type, char* string);
	static void Special(const char* type, const char* formatString, ...);
	
	// Writes the boot header to the standard UART stream.
	static void WriteBootHeader();

private:
	static Log::OutputLevel currentTraceLevel;

};