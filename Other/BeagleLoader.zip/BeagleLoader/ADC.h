#pragma once
#include "Component.h"

class ADC
{
public:
	ADC();
	~ADC();

	static void ADCInterrupt();
};
