#include "UART.h"
#include "Log.h"

#include "gpio_v2.h"

#include "hw_control_AM335x.h"
#include "soc_AM335x.h"
#include "beaglebone.h"
#include "hw_cm_wkup.h"
#include "hw_cm_per.h"
#include "hw_types.h"
#include "uart_irda_cir.h"

#include "string.h"
#include "limits.h"

#include "interrupt.h"
#include "Bootloader.h"

#define UART_REGISTER     SOC_UART_2_REGS

int UART::readBuffer[BUFFER_SIZE] = {};
int UART::payloadBuffer[BUFFER_SIZE] = {};
int UART::rBufferPos = 0;
bool UART::clearPayload = false;

//constructor
UART::UART() {

}
//destructor
UART::~UART() {

}


const unsigned int UART::BaudRate = 115200;
const signed char UART::START_MESSAGE = 0x02;
const signed char UART::END_MESSAGE = 0x04;
const signed char UART::HEADER_BIT = 0x80;
const signed char UART::ACK_BIT = 0x40;
const signed char UART::ESCAPE_BIT = 0x10;

void UART::InterruptEnable() {
    /* Registering the Interrupt Service Routine(ISR). */
    IntRegister(SYS_INT_UART2INT, UARTIsr);

    /* Setting the priority for the system interrupt in AINTC. */
    IntPrioritySet(SYS_INT_UART2INT, 1, AINTC_HOSTINT_ROUTE_IRQ);

    /* Enabling the system interrupt in AINTC. */
    IntSystemEnable(SYS_INT_UART2INT);    

    /* Enabling the specified UART interrupts. */
    UARTIntEnable(SOC_UART_2_REGS, UART_INT_RHR_CTI);
}

signed char UART::ReadData() {
	signed char data = UARTCharGetNonBlocking(UART_REGISTER);
	//return reinterpret_cast<unsigned char&>(data);
	return data;
}

signed char UART::ReadDataBlocking() {
	signed char data = UARTCharGetTimeout(UART_REGISTER, 20000);
	return data;
}

//Reads new bytes until the start of a message is reached, or returns 0 if no new bytes
signed char UART::MoveNextCommand() {
	signed char data = 0;
	while(data != UART::START_MESSAGE) {
		data = ReadData();
		if (data == -1) {
			return 0;
		}
	}
	return data;
}

//Sample Command: 0x02 0x81 0x80  0x81  0x01  0x81   0x04
//               start  L1   L2   cmdID  pl1  chksm  end
//Calls SALUT_INIT_DIR_MODE with no request for acknowledgement
int* UART::ReadCommand() {
	int sum = 0;
	ClearBuffer(readBuffer);

	//Determine if we have a new message, otherwise return previous message
	if (MoveNextCommand() == 0) {
		return UART::readBuffer;
	} 

	//read first length byte and flip back the MSB (0x80)
	signed char length1 = ReadDataBlocking();
	sum += length1;
	length1 = length1 & ~(HEADER_BIT);

	//read second length byte, flip back MSB and extract ACK bit (0x40)
	signed char length2 = ReadDataBlocking();
	sum += length2;
	signed char ack = (length2 >> 6) & 0x01;
	length2 = length2 & ~(HEADER_BIT) & ~(ACK_BIT);

	//calculate total length by combining both length bytes, shifting length2 by 7 bits as per SNIC spec
	unsigned int length = (length2 << 7) + length1;
	
	//watch out for read buffer overflow, just return 0 if too long 
	//this makes sense because current protocol design should never have a payload longer than this
	//if length is read longer than that, package is malformed
	if (length > BUFFER_SIZE - 2) {
		Log::Trace("Length too long");
		return UART::readBuffer;
	}
	
	//read commandID and flip back the MSB
	signed char commandID = ReadDataBlocking();
	sum += commandID;
	commandID = commandID & ~HEADER_BIT;

	//read payload bytes into array specified by calculated length
	signed char payload[length];
	for (unsigned int i = 0; i < length; i++) {
		payload[i] = ReadDataBlocking();
		sum += payload[i];
	}

	signed char checksum =  ReadDataBlocking();
	checksum = checksum & ~HEADER_BIT;

	//if END_MESSAGE byte (0x04) is not reached at this point, something went wrong. Return 0 
	if (ReadDataBlocking() != UART::END_MESSAGE) {
		Log::Trace("Malformed Message");
		return UART::readBuffer;
	}

	if (!VerifyChecksum(checksum, sum)) {
		Log::Trace("Bad Checksum");
		SendNAK();
		return UART::readBuffer;
	}

	//build results for Simulink into global readBuffer array, skipping escape characters in payload
	UART::readBuffer[ACK] = ack;
	UART::readBuffer[CMD_ID] = commandID;

	int position = 2;
	for (unsigned int i = 0; i < length; i++) {
		if (payload[i] == ESCAPE_BIT) {
			UART::readBuffer[position] = payload[i + 1] & ~HEADER_BIT;
			i++;
		} else {
			UART::readBuffer[position] = payload[i];
		}
		position++;
	}
	if (ack) {
		SendACK();
	} 
	
	return UART::readBuffer;
}

//receive array of command bytes from Simulink or elsewhere and send over UART
void UART::WriteCommand(signed char commandID, signed char* payload, int length, bool ack = false) {
	int escapedLength = CalculateEscapedLength(payload, length);
	signed char writeBuffer[escapedLength + 6];
	signed char checksum = 0;

	writeBuffer[0] = UART::START_MESSAGE;
	checksum += writeBuffer[1] = (escapedLength & 0xFF) | UART::HEADER_BIT;
	checksum += writeBuffer[2] = ((escapedLength >> 7) & 0xFF) | UART::HEADER_BIT | (ack ? UART::ACK_BIT : 0x00);
	checksum += writeBuffer[3] = commandID | HEADER_BIT;

	int position = 4;
	for (int i = 0; i < length; i++) {
		if (RequiresEscape(payload[i])) {
			checksum += writeBuffer[position] = ESCAPE_BIT;
			payload[i] = payload[i] | HEADER_BIT; //Ricky is flipping header bit on escaped payload characters, no idea why
			position++;
		}
		checksum += writeBuffer[position] = payload[i];
		position++;
	}
	writeBuffer[position] = checksum | HEADER_BIT;
	writeBuffer[position + 1] = UART::END_MESSAGE;

	for (int i = 0; i < escapedLength + 6; i++) {
		//reinterpret cast to make sure signed to unsigned conversion isn't doing something screwy with the MSB
		UARTCharPut(UART_REGISTER, reinterpret_cast<unsigned char&>(writeBuffer[i]));
	}
}

int* UART::VerifyReadBuffer() {
	int sum = 0;

	//Determine if we have a new message, otherwise return previous message

	//read first length byte and flip back the MSB (0x80)
	signed char length1 = UART::readBuffer[1];
	sum += length1;
	length1 = length1 & ~(HEADER_BIT);

	//read second length byte, flip back MSB and extract ACK bit (0x40)
	signed char length2 = UART::readBuffer[2];
	sum += length2;
	signed char ack = (length2 >> 6) & 0x01;
	length2 = length2 & ~(HEADER_BIT) & ~(ACK_BIT);

	//calculate total length by combining both length bytes, shifting length2 by 7 bits as per SNIC spec
	unsigned int length = (length2 << 7) + length1;
	
	//watch out for read buffer overflow, just return 0 if too long 
	//this makes sense because current protocol design should never have a payload longer than this
	//if length is read longer than that, package is malformed
	if (length > BUFFER_SIZE - 2) {
		Log::Trace("Length too long");
		return UART::payloadBuffer;
	}
	
	//read commandID and flip back the MSB
	signed char commandID = UART::readBuffer[3];
	sum += commandID;
	commandID = commandID & ~HEADER_BIT;

	//read payload bytes into array specified by calculated length
	signed char payload[length];
	int position = 4;
	for (unsigned int i = 0; i < length; i++) {
		payload[i] = UART::readBuffer[position + i];
		sum += payload[i];
	}
	position += length;

	signed char checksum =  UART::readBuffer[position];
	checksum = checksum & ~HEADER_BIT;

	//if END_MESSAGE byte (0x04) is not reached at this point, something went wrong. Return 0 
	if (UART::readBuffer[position + 1] != UART::END_MESSAGE) {
		Log::Trace("Malformed Message");
		return UART::payloadBuffer;
	}

	if (!VerifyChecksum(checksum, sum)) {
		Log::Trace("Bad Checksum");
		SendNAK();
		return UART::payloadBuffer;
	}

	//build results for Simulink into global readBuffer array, skipping escape characters in payload
	ClearBuffer(UART::payloadBuffer);

	UART::payloadBuffer[ACK] = ack;
	UART::payloadBuffer[CMD_ID] = commandID;

	position = 2;
	for (unsigned int i = 0; i < length; i++) {
		if (payload[i] == ESCAPE_BIT) {
			UART::payloadBuffer[position] = payload[i + 1] & ~HEADER_BIT;
			i++;
		} else {
			UART::payloadBuffer[position] = payload[i];
		}
		position++;
	}
	if (ack) {
		SendACK();
	}
	return UART::payloadBuffer;
}

void UART::SendACK() {
	UART::WriteCommand(0x7F, 0, 0);
}

void UART::SendNAK() {
	UART::WriteCommand(0x00, 0, 0);
}

bool UART::VerifyChecksum(signed char checksum, signed char sum){
	return checksum == (sum & ~HEADER_BIT);
}

void UART::ClearBuffer(int* buffer) {
	for (int i = 0; i < BUFFER_SIZE; i++) {
		buffer[i] = 0;
	}
}

bool UART::BufferCleared(int* buffer) {
	bool empty = true;
	for (int i = 0; i < BUFFER_SIZE; i++) {
		if (buffer[i]) {
			empty = false;
			break;
		}
	}
	return empty;
}

//determine required length for payload including any escape characters
int UART::CalculateEscapedLength(signed char* payload, int length) {
	int escapedLength = 0;
	for (int i = 0; i < length; i++) {
		if (RequiresEscape(payload[i]))  {
			escapedLength += 2;
		} else {
			escapedLength++;
		}
	}
	return escapedLength;
}

bool UART::RequiresEscape(signed char byte) {
	return (byte == UART::START_MESSAGE || byte == UART::END_MESSAGE || byte == UART::ESCAPE_BIT);
}

void UART::DebugWrite(const char* message) {
	size_t length = strlen(message);
	if (length < INT_MAX) {
		WriteCommand(0x06, (signed char*)message, (int)strlen(message));		
	}
}

void UART::UARTIsr(void) {
 	/* Checking the source of UART interrupt. */
 	CheckClearPayload();
    int intId = UARTIntIdentityGet(SOC_UART_2_REGS);
    switch (intId)
    {
    	case UART_INTID_RX_THRES_REACH:
    		//If currently stored payload has been read by model, clear it and get another one
    		//If payload is cleared (by reading from model), build a new one
    		if (BufferCleared(UART::payloadBuffer)) {
	    		signed char data = ReadData();
	    		if (rBufferPos > BUFFER_SIZE - 1) {
	    			Log::Error("UART Buffer Overflow");
	    			ClearBuffer(UART::readBuffer);
	    			rBufferPos = 0;
	    		} else {
	    			ParseDataByte(data);
	    		}
    		}
    	break;

    	default:
    	break;
    }
}

void UART::CheckClearPayload() {
	if (UART::clearPayload) {
		ClearBuffer(UART::payloadBuffer);
		UART::clearPayload = false;
	}
}

void UART::ParseDataByte(signed char byte) {
	if (byte == UART::START_MESSAGE && BufferCleared(UART::readBuffer)) {
		UART::readBuffer[0] = byte;
		rBufferPos = 1;
	} else if (byte == UART::END_MESSAGE && !IsEscaped(UART::readBuffer, rBufferPos)) {
		UART::readBuffer[rBufferPos] = byte;
		VerifyReadBuffer();
		ClearBuffer(UART::readBuffer);
	} else {
		UART::readBuffer[rBufferPos] = byte;
		rBufferPos++;
	}
}

int* UART::ReadPayloadBuffer() {
	CheckClearPayload();
	if (!BufferCleared(UART::payloadBuffer)) {
		UART::clearPayload = true;
	}

	return UART::payloadBuffer;
}

void UART::WritePayloadToModel() {
	vectors.WriteUARTPayload(ReadPayloadBuffer());
}
//This is stupidly unlikely, but it could definitely happen, ie:
// 0x10 0x10 0x10 0x10 0x04 - the last bit is unescaped because even # of escape bits preceding
bool UART::IsEscaped(int* buffer, int pos) {
	int index = pos - 1;
	while(index > 0 && buffer[index] == UART::ESCAPE_BIT)
		index--;
	return (((pos - 1) - index) % 2);
}