#pragma once
class I2C
{
public:
	I2C();
	~I2C();

	struct DataBuffer
	{
		bool Complete;
		unsigned int ExpectedBytes;
		unsigned char Data[128];
		unsigned int Count = 0;
	};

	static DataBuffer TransmitBuffer[2];
	static DataBuffer ReceiveBuffer[2];

	static bool FirstCommandExecuted[2];

	static bool StopCondition[2];
	static bool NoACKCondition[2];

	static void Configure();
	static void Start(unsigned int module, unsigned int slaveAddress);
	static bool Write(unsigned int module);
	static bool Read(unsigned int module, unsigned char numBytes);

	static void SetSlaveAddress(unsigned char module, unsigned char slaveAddress);

	static void SetContinuedMode();
	static void SetNonContinuedMode();

	static void ISRModule1();
	static void ISRModule2();

private:
	static void ConfigureClock1();
	static void ConfigureClock2();

	static bool ContinuedMode;

	static unsigned int ModuleRegs[2];
};

#define I2C_Module1 0
#define I2C_Module2 1

// This should really be instantiated as two separate instances, one for each I2C module.... but all out of time