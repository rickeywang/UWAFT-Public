#pragma once
class UART
{
public:
	UART();
	~UART();
	static const unsigned int BaudRate;
	static const signed char START_MESSAGE;
	static const signed char END_MESSAGE;
	static const signed char HEADER_BIT;
	static const signed char ACK_BIT;
	static const signed char ESCAPE_BIT;
	static const signed char BUFFER_SIZE = 100;

	static int readBuffer[BUFFER_SIZE];
	static int payloadBuffer[BUFFER_SIZE];

	static bool clearPayload;
	static int rBufferPos;

	static signed char ReadData();
	static signed char ReadDataBlocking();
	static signed char MoveNextCommand();
	static int* ReadCommand();
	static void WriteCommand(signed char commandID, signed char* payload, int length, bool ack);
	static int* VerifyReadBuffer();
	static void SendACK();
	static void SendNAK();
	static bool VerifyChecksum(signed char checksum, signed char sum);
	static void ClearBuffer(int* buffer);
	static void DebugWrite(const char* message);
	static void InterruptEnable();
	static void UARTIsr(void);
	static int* ReadPayloadBuffer();
	static void WritePayloadToModel();
private:
	static int CalculateEscapedLength(signed char* payload, int length);
	static bool RequiresEscape(signed char byte);
	static bool IsEscaped(int* buffer, int pos);
	static bool BufferCleared(int* buffer);
	static void CheckClearPayload();
	static void ParseDataByte(signed char byte);

};

/*Serial Protol Byte Definitions*/
#define CMD_ID_FMWR_UPDATE      0x60
#define CMD_ID_REQUEST_BOOT     0x61
#define RSP_BOOT_UPDATE     	0x61
#define RSP_BOOT_MODEL      	0x62
#define UPDATE_FIRMWARE     	0x01
#define UPDATE_MODEL     		0x02
#define UPDATE_DONE      		0x06

/* Read Buffer byte positions */	
#define ACK     				0
#define CMD_ID  				1
#define SUB_ID  				2
