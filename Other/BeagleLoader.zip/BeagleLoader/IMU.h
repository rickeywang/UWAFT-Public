#pragma once
class IMU
{
public:
	IMU();
	~IMU();

	struct DataSet
	{
		signed short int XAxis;
		signed short int YAxis;
		signed short int ZAxis;
		float Scale;
	};

	static DataSet Accelerometer;
	static DataSet Gyroscope;
	static DataSet Magnetometer;

	// The I2C address of the accelerometer and magnetometer.
	static const unsigned char AccelMagAddress = 0b0011101;
	// The I2C address of the gyroscope
	static const unsigned char GyroAddress     = 0b1101011;

	// The WHO_AM_I_XM register default value
	static const unsigned char AccelMagWhoAmI  = 0b01001001;
	// The WHO_AM_I_G register default value
	static const unsigned char GyroWhoAmI      = 0b11010100;

	// Gets the gyroscope WHO_AM_I register by actively requesting it from the IMU hardware (not by returning IMU::GyroAddress).
	static unsigned char GetGyroAddress();
	// Gets the accelerometer and magnetometer WHO_AM_I register by actively requesting it from the IMU hardware (not by returning IMU::AccelMagAddress).
	static unsigned char GetAccelAddress();

	// Reads the gyroscope data and stores it
	static DataSet* GetGyroscopeData();

	// Reads the accelerometer data and stores it
	static DataSet* GetAccelerometerData();

	// Reads the magnetometer data and stores it
	static DataSet* GetMagnetometerData();

	// Preforms a communication check with the IMU hardware, requests the gyroscope and accelerometer WHO_AM_I addresses. Returns true if communication was successfully established, otherwise false.
	static bool CommunicationCheck();

	static void ConfigureIMU();

	static void WritePayloadToModel();

private:
	static unsigned char Read(unsigned char address, unsigned char subAddress);

	static bool Write(unsigned char address, unsigned char subAddress, unsigned char value);
	static bool Write(unsigned char address, unsigned char subAddress, unsigned char* values, unsigned char count);
};

// IMU Register definitions
#define GYRO_WHO_AM_I     0x0F

#define GYRO_CTRL_REG1    0x20
#define GYRO_CTRL_REG2    0x21
#define GYRO_CTRL_REG3    0x22
#define GYRO_CTRL_REG4    0x23
#define GYRO_CTRL_REG5    0x24

#define GYRO_REFERENCE    0x25
#define GYRO_STATUS       0x27
#define GYRO_X_L          0x28
#define GYRO_X_H          0x29
#define GYRO_Y_L          0x2A
#define GYRO_Y_H          0x2B
#define GYRO_Z_L          0x2C
#define GYRO_Z_H          0x2D

#define MAGACCL_WHO_AM_I  0x0F

#define MAGACCL_CTRL_REG0 0x1F
#define MAGACCL_CTRL_REG1 0x20
#define MAGACCL_CTRL_REG2 0x21
#define MAGACCL_CTRL_REG3 0x22
#define MAGACCL_CTRL_REG4 0x23
#define MAGACCL_CTRL_REG5 0x24
#define MAGACCL_CTRL_REG6 0x25
#define MAGACCL_CTRL_REG7 0x26

#define MAG_TEMP_L        0x05
#define MAG_TEMP_H        0x06
#define MAG_X_L           0x08
#define MAG_X_H           0x09
#define MAG_Y_L           0x0A
#define MAG_Y_H           0x0B
#define MAG_Z_L           0x0C
#define MAG_Z_H           0x0D

#define MAG_OFFSET_X_L    0x16
#define MAG_OFFSET_X_H    0x17   
#define MAG_OFFSET_Y_L    0x18
#define MAG_OFFSET_Y_H    0x19
#define MAG_OFFSET_Z_L    0x1A
#define MAG_OFFSET_Z_H    0x1B

#define ACCL_X_L          0x28
#define ACCL_X_H          0x29
#define ACCL_Y_L          0x2A
#define ACCL_Y_H          0x2B
#define ACCL_Z_L          0x2C
#define ACCL_Z_H          0x2D