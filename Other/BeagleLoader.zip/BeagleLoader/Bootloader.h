#pragma once
#include "IMU.h"
#include "Encoder.h"

class Bootloader
{
public:
	Bootloader();
	~Bootloader();

	static void Bootload();
	static void CreateUpdateFile(char* name);
	static void WriteUpdateChunk(char* chunk);
	static void FinishUpdate();
};

struct EntryVectors
{
	void (*SimulationSetup)();
	void (*SimulationStep)();
	void (*SetWheelSpeed)(double);
	void (*ADCInterrupt)();
	void (*UpdateIMUValues)(IMU::DataSet*, IMU::DataSet*, IMU::DataSet*);
	void (*WriteUARTPayload)(int*);
	void (*UpdateEncoderValues)(Encoder::EncoderValues*);
	void (*Reserved6)();
	void (*Reserved7)();
};

extern EntryVectors vectors;

const unsigned int ModelVectorTable = 0x80020000;
