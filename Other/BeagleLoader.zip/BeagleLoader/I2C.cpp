#include "I2C.h"
#include "Pad.h"
#include "Log.h"

#include "hsi2c.h"
#include "beaglebone.h"
#include "soc_AM335x.h"
#include "hw_cm_per.h"
#include "hw_control_AM335x.h"
#include "interrupt.h"

I2C::I2C()
{
}

I2C::~I2C()
{
}

I2C::DataBuffer I2C::TransmitBuffer[2];
I2C::DataBuffer I2C::ReceiveBuffer[2];

bool I2C::FirstCommandExecuted[2] = { false, false };

bool I2C::StopCondition[2];
bool I2C::NoACKCondition[2];

bool I2C::ContinuedMode = false;

unsigned int I2C::ModuleRegs[2] = { SOC_I2C_1_REGS, SOC_I2C_2_REGS };

void I2C::Configure()
{
	// Interrupts
	// Register module 1 interrupt routine
	/* Registering the Interrupt Service Routine(ISR). */
	IntRegister(SYS_INT_I2C1INT, I2C::ISRModule1);

	/* Setting the priority for the system interrupt in AINTC. */
	IntPrioritySet(SYS_INT_I2C1INT, 10, AINTC_HOSTINT_ROUTE_IRQ);

	/* Enabling the system interrupt in AINTC. */
	IntSystemEnable(SYS_INT_I2C1INT);

	// Register module 2 interrupt routine
	/* Registering the Interrupt Service Routine(ISR). */
	IntRegister(SYS_INT_I2C2INT, I2C::ISRModule2);

	/* Setting the priority for the system interrupt in AINTC. */
	IntPrioritySet(SYS_INT_I2C2INT, 11, AINTC_HOSTINT_ROUTE_IRQ);

	/* Enabling the system interrupt in AINTC. */
	IntSystemEnable(SYS_INT_I2C2INT);

	/* Enable the clocks for I2C0 */
	I2C::ConfigureClock1();
	I2C::ConfigureClock2();

	// Setup the pin mux for the I2C pins
	Pad::MuxPad(0, 5, Pad::GetPadConfiguration(2, true, true, false, true)); // I2C 1 SCL
	Pad::MuxPad(0, 4, Pad::GetPadConfiguration(2, true, true, false, true)); // I2C 1 SDA

	Pad::MuxPad(0, 13, Pad::GetPadConfiguration(3, true, true, false, true)); // I2C 2 SCL
	Pad::MuxPad(0, 12, Pad::GetPadConfiguration(3, true, true, false, true)); // I2C 2 SDA

	// Configured
}

void I2C::Start(unsigned int module, unsigned int slaveAddress)
{
	if (module == 0)
	{
		/* Put i2c in reset/disabled state */
		I2CMasterDisable(SOC_I2C_1_REGS);

		/* Disable auto Idle functionality */
		I2CAutoIdleDisable(SOC_I2C_1_REGS);

		/* Configure i2c bus speed to 100khz */
		I2CMasterInitExpClk(SOC_I2C_1_REGS, 48000000, 12000000, 100000);

		/* Set i2c slave address */
		I2CMasterSlaveAddrSet(SOC_I2C_1_REGS, slaveAddress);

		/* Bring I2C out of reset */
		I2CMasterEnable(SOC_I2C_1_REGS);

	}
	else if (module == 1)
	{
		/* Put i2c in reset/disabled state */
		I2CMasterDisable(SOC_I2C_2_REGS);

		/* Disable auto Idle functionality */
		I2CAutoIdleDisable(SOC_I2C_2_REGS);

		/* Configure i2c bus speed to 100khz */
		I2CMasterInitExpClk(SOC_I2C_2_REGS, 48000000, 12000000, 400000);

		/* Set i2c slave address */
		I2CMasterSlaveAddrSet(SOC_I2C_2_REGS, slaveAddress);

		/* Bring I2C out of reset */
		I2CMasterEnable(SOC_I2C_2_REGS);
	}
}

bool I2C::Write(unsigned int module)
{
	if (module == 0)
	{
		/* Wait untill I2C registers are ready to access */
		while (FirstCommandExecuted[I2C_Module1] && !(I2CMasterIntRawStatus(SOC_I2C_1_REGS) & (I2C_INT_ADRR_READY_ACESS)));
		FirstCommandExecuted[I2C_Module1] = true;

		TransmitBuffer[I2C_Module1].Count = 0;
		TransmitBuffer[I2C_Module1].Complete = false;

		/* Data Count specifies the number of bytes to be transmitted */
		I2CSetDataCount(SOC_I2C_1_REGS, TransmitBuffer[I2C_Module1].ExpectedBytes);

		/* Clear status of all interrupts */
		I2CMasterIntEnableEx(SOC_I2C_1_REGS, 0x7FF);
		I2CMasterIntClearEx(SOC_I2C_1_REGS, 0x7FF);
		I2CMasterIntDisableEx(SOC_I2C_1_REGS, 0x7FF);

		/* Configure I2C controller in Master Transmitter mode */
		I2CMasterControl(SOC_I2C_1_REGS, I2C_CFG_MST_TX);

		/* Transmit interrupt is enabled */
		I2CMasterIntEnableEx(SOC_I2C_1_REGS, I2C_INT_TRANSMIT_READY);

		/* Generate Start Condition over I2C bus */
		I2CMasterStart(SOC_I2C_1_REGS);
		
		int timeout = 0;
		while (!TransmitBuffer[I2C_Module1].Complete && timeout++ < 10000);
		if (timeout >= 10000) {
			Log::Info("Write Transmit Buffer 1 Fail");
		}
		// The bus is busy if the master does not issue a STOP command, if we're in continued mode, 
		//  there won't be a STOP command issued
		timeout = 0;
		while (!I2C::ContinuedMode && I2CMasterBusBusy(SOC_I2C_1_REGS) && timeout++ < 10000);
		if (timeout >= 10000) {
			Log::Info("Write Master Bus 1 Fail");
		}
		return true;
	}
	else if (module == 1)
	{
		/* Wait untill I2C registers are ready to access */
		while (FirstCommandExecuted[I2C_Module2] && !(I2CMasterIntRawStatus(SOC_I2C_2_REGS) & (I2C_INT_ADRR_READY_ACESS)));
		FirstCommandExecuted[I2C_Module2] = true;

		TransmitBuffer[I2C_Module2].Count = 0;
		TransmitBuffer[I2C_Module2].Complete = false;

		/* Data Count specifies the number of bytes to be transmitted */
		I2CSetDataCount(SOC_I2C_2_REGS, TransmitBuffer[I2C_Module2].ExpectedBytes);

		//TransmitBuffer[I2C_Module2].ExpectedBytes = I2CDataCountGet(SOC_I2C_2_REGS);

		/* Clear status of all interrupts */
		I2CMasterIntEnableEx(SOC_I2C_2_REGS, 0x7FF);
		I2CMasterIntClearEx(SOC_I2C_2_REGS, 0x7FF);
		I2CMasterIntDisableEx(SOC_I2C_2_REGS, 0x7FF);

		/* Configure I2C controller in Master Transmitter mode */
		I2CMasterControl(SOC_I2C_2_REGS, I2C_CFG_MST_TX);

		/* Transmit interrupt is enabled */
		I2CMasterIntEnableEx(SOC_I2C_2_REGS, I2C_INT_TRANSMIT_READY);

		/* Generate Start Condition over I2C bus */
		I2CMasterStart(SOC_I2C_2_REGS);

		int timeout = 0;
		while (!TransmitBuffer[I2C_Module2].Complete && timeout++ < 10000);
		if (timeout >= 10000) {
			Log::Info("Write Transmit Buffer 2 Fail");
		}
		timeout = 0;
		while (I2CMasterBusBusy(SOC_I2C_2_REGS) && timeout++ < 10000);
		if (timeout >= 10000) {
			Log::Info("Write Transmit Buffer 2 Fail");
		}
		return true;
	}
	return false;
}

bool I2C::Read(unsigned int module, unsigned char numBytes)
{
	if (module == 0)
	{
		/* Wait untill I2C registers are ready to access */
		while (FirstCommandExecuted[I2C_Module1] && !(I2CMasterIntRawStatus(SOC_I2C_1_REGS) & (I2C_INT_ADRR_READY_ACESS)));
		FirstCommandExecuted[I2C_Module1] = true;

		/* Data Count specifies the number of bytes to be received */
		I2CSetDataCount(SOC_I2C_1_REGS, numBytes);

		ReceiveBuffer[I2C_Module1].Complete = false;
		ReceiveBuffer[I2C_Module1].Count = 0;
		ReceiveBuffer[I2C_Module1].ExpectedBytes = numBytes;

		I2CMasterIntEnableEx(SOC_I2C_1_REGS, 0x7FF);
		I2CMasterIntClearEx(SOC_I2C_1_REGS, 0x7FF);
		I2CMasterIntDisableEx(SOC_I2C_1_REGS, 0x7FF);

		/* Configure I2C controller in Master Receiver mode */
		I2CMasterControl(SOC_I2C_1_REGS, I2C_CFG_MST_RX);

		/* Receive and Stop Condition Interrupts are enabled */
		I2CMasterIntEnableEx(SOC_I2C_1_REGS, I2C_INT_RECV_READY |
			I2C_INT_STOP_CONDITION);

		/* Generate Start Condition over I2C bus */
		I2CMasterStart(SOC_I2C_1_REGS);

		int timeout = 0;
		while (I2CMasterBusBusy(SOC_I2C_1_REGS) == 0 && timeout++ < 10000);
		if (timeout >= 10000) {
			Log::Info("Read Master Bus 1 Fail");
		}
		timeout = 0;
		while (!ReceiveBuffer[I2C_Module1].Complete && timeout++ < 10000);
		if (timeout >= 10000) {
			Log::Info("Read Receive Buffer 1 Fail");
		}

		/* Wait untill I2C registers are ready to access for the next command */
		timeout = 0;
		while (!(I2CMasterIntRawStatus(SOC_I2C_1_REGS) & (I2C_INT_ADRR_READY_ACESS)) && timeout++ < 10000);
		if (timeout >= 10000) {
			Log::Info("Read Master Status 1 Fail");
		}

		return true;
	}
	else if (module == 1)
	{
		/* Wait untill I2C registers are ready to access */
		while (FirstCommandExecuted[I2C_Module2] && !(I2CMasterIntRawStatus(SOC_I2C_2_REGS) & (I2C_INT_ADRR_READY_ACESS)));
		FirstCommandExecuted[I2C_Module2] = true;

		/* Data Count specifies the number of bytes to be received */
		I2CSetDataCount(SOC_I2C_2_REGS, numBytes);

		ReceiveBuffer[I2C_Module2].Complete = false;
		ReceiveBuffer[I2C_Module2].Count = 0;
		ReceiveBuffer[I2C_Module2].ExpectedBytes = numBytes;

		I2CMasterIntEnableEx(SOC_I2C_2_REGS, 0x7FF);
		I2CMasterIntClearEx(SOC_I2C_2_REGS, 0x7FF);
		I2CMasterIntDisableEx(SOC_I2C_2_REGS, 0x7FF);

		/* Configure I2C controller in Master Receiver mode */
		I2CMasterControl(SOC_I2C_2_REGS, I2C_CFG_MST_RX);

		/* Receive and Stop Condition Interrupts are enabled */
		I2CMasterIntEnableEx(SOC_I2C_2_REGS, I2C_INT_RECV_READY |
			I2C_INT_STOP_CONDITION);

		/* Generate Start Condition over I2C bus */
		I2CMasterStart(SOC_I2C_2_REGS);
		int timeout = 0;
		while (I2CMasterBusBusy(SOC_I2C_2_REGS) == 0 && timeout++ < 10000);
		if (timeout >= 10000) {
			Log::Info("Read Master Bus 2 Fail");
		}
		timeout = 0;
		while (!ReceiveBuffer[I2C_Module2].Complete && timeout++ < 10000);
		if (timeout >= 10000) {
			Log::Info("Read Receive Buffer 2 Fail");
		}

		/* Wait untill I2C registers are ready to access for the next command */
		timeout = 0;
		while (!(I2CMasterIntRawStatus(SOC_I2C_2_REGS) & (I2C_INT_ADRR_READY_ACESS)) && timeout++ < 10000);
		if (timeout >= 10000) {
			Log::Info("Read Master Status 2 Fail");
		}
		return true;
	}

	return false;
}

void I2C::ISRModule1()
{
	DataBuffer* ReceiveBuffer = &(I2C::ReceiveBuffer[I2C_Module1]);
	DataBuffer* TransmitBuffer = &(I2C::TransmitBuffer[I2C_Module1]);
	unsigned int status = 0;

	/* Get only Enabled interrupt status */
	status = I2CMasterIntStatus(SOC_I2C_1_REGS);

	/*
	** Clear all enabled interrupt status except receive ready and
	** transmit ready interrupt status
	*/
	I2CMasterIntClearEx(SOC_I2C_1_REGS,
		(status & ~(I2C_INT_RECV_READY | I2C_INT_TRANSMIT_READY)));

	if (status & I2C_INT_RECV_READY)
	{
		/* Receive data from data receive register */
		ReceiveBuffer->Data[ReceiveBuffer->Count++] = I2CMasterDataGet(SOC_I2C_1_REGS);

		/* Clear receive ready interrupt status */
		I2CMasterIntClearEx(SOC_I2C_1_REGS, I2C_INT_RECV_READY);

		if (ReceiveBuffer->Count == ReceiveBuffer->ExpectedBytes)
		{
			/* Disable the receive ready interrupt */
			I2CMasterIntDisableEx(SOC_I2C_1_REGS, I2C_INT_RECV_READY);
			if (!I2C::ContinuedMode)
			{
				/* Generate a STOP */
				I2CMasterStop(SOC_I2C_1_REGS);
			}

			// Reset the receive buffer expected bytes
			ReceiveBuffer->ExpectedBytes = 0;
			ReceiveBuffer->Complete = true;
		}
	}

	if (status & I2C_INT_TRANSMIT_READY)
	{
		/* Put data to data transmit register of i2c */
		I2CMasterDataPut(SOC_I2C_1_REGS, TransmitBuffer->Data[TransmitBuffer->Count]);
		TransmitBuffer->Count++;
		//CMasterDataPut(SOC_I2C_1_REGS, dataToSlave[tCount++]);

		if (TransmitBuffer->Count == TransmitBuffer->ExpectedBytes)
		{
			/* Disable the transmit ready interrupt */
			I2CMasterIntDisableEx(SOC_I2C_1_REGS, I2C_INT_TRANSMIT_READY);
			if (!I2C::ContinuedMode)
			{
				I2CMasterStop(SOC_I2C_1_REGS);
			}
			TransmitBuffer->Complete = true;
		}

		/* Clear Transmit interrupt status */
		I2CMasterIntClearEx(SOC_I2C_1_REGS, I2C_INT_TRANSMIT_READY);
	}

	if (status & I2C_INT_STOP_CONDITION)
	{
		/* Disable transmit data ready and receive data read interupt */
		I2CMasterIntDisableEx(SOC_I2C_1_REGS, I2C_INT_TRANSMIT_READY |
			I2C_INT_RECV_READY |
			I2C_INT_STOP_CONDITION);
		StopCondition[I2C_Module1] = 0;
	}

	if (status & I2C_INT_NO_ACK)
	{
		I2CMasterIntDisableEx(SOC_I2C_1_REGS, I2C_INT_TRANSMIT_READY |
			I2C_INT_RECV_READY |
			I2C_INT_NO_ACK |
			I2C_INT_STOP_CONDITION);
		/* Generate a STOP */
		I2CMasterStop(SOC_I2C_1_REGS);

		// Technically done both
		ReceiveBuffer->Complete = true;
		TransmitBuffer->Complete = true;

		NoACKCondition[I2C_Module1] = 0;
	}
}

void I2C::ISRModule2()
{
	DataBuffer* ReceiveBuffer = &(I2C::ReceiveBuffer[I2C_Module2]);
	DataBuffer* TransmitBuffer = &(I2C::TransmitBuffer[I2C_Module2]);
	unsigned int status = 0;

	/* Get only Enabled interrupt status */
	status = I2CMasterIntStatus(SOC_I2C_2_REGS);

	/*
	** Clear all enabled interrupt status except receive ready and
	** transmit ready interrupt status
	*/
	I2CMasterIntClearEx(SOC_I2C_2_REGS,
		(status & ~(I2C_INT_RECV_READY | I2C_INT_TRANSMIT_READY)));

	if (status & I2C_INT_RECV_READY)
	{
		/* Receive data from data receive register */
		ReceiveBuffer->Data[ReceiveBuffer->Count++] = I2CMasterDataGet(SOC_I2C_2_REGS);

		/* Clear receive ready interrupt status */
		I2CMasterIntClearEx(SOC_I2C_2_REGS, I2C_INT_RECV_READY);

		if (ReceiveBuffer->Count == ReceiveBuffer->ExpectedBytes)
		{
						
			/* Disable the receive ready interrupt */
			I2CMasterIntDisableEx(SOC_I2C_2_REGS, I2C_INT_RECV_READY);
			/* Generate a STOP */
			I2CMasterStop(SOC_I2C_2_REGS);

			// Reset the receive buffer expected bytes
			ReceiveBuffer->ExpectedBytes = 0;
			ReceiveBuffer->Complete = true;

		}
	}

	if (status & I2C_INT_TRANSMIT_READY)
	{
		/* Put data to data transmit register of i2c */
		I2CMasterDataPut(SOC_I2C_2_REGS, TransmitBuffer->Data[TransmitBuffer->Count++]);

		/* Clear Transmit interrupt status */
		I2CMasterIntClearEx(SOC_I2C_2_REGS, I2C_INT_TRANSMIT_READY);

		if (TransmitBuffer->Count == ReceiveBuffer->ExpectedBytes)
		{
			/* Disable the transmit ready interrupt */
			I2CMasterIntDisableEx(SOC_I2C_2_REGS, I2C_INT_TRANSMIT_READY);

			TransmitBuffer->Complete = true;
		}

	}

	if (status & I2C_INT_STOP_CONDITION)
	{
		/* Disable transmit data ready and receive data read interupt */
		I2CMasterIntDisableEx(SOC_I2C_2_REGS, I2C_INT_TRANSMIT_READY |
			I2C_INT_RECV_READY |
			I2C_INT_STOP_CONDITION);
		StopCondition[I2C_Module2] = 0;
	}

	if (status & I2C_INT_NO_ACK)
	{
		I2CMasterIntDisableEx(SOC_I2C_2_REGS, I2C_INT_TRANSMIT_READY |
			I2C_INT_RECV_READY |
			I2C_INT_NO_ACK |
			I2C_INT_STOP_CONDITION);
		/* Generate a STOP */
		I2CMasterStop(SOC_I2C_2_REGS);

		ReceiveBuffer->Complete = true;
		TransmitBuffer->Complete = true;

		NoACKCondition[I2C_Module2] = 0;
	}
}

void I2C::SetSlaveAddress(unsigned char module, unsigned char slaveAddress)
{
	I2CMasterSlaveAddrSet(ModuleRegs[module], slaveAddress);
}

void I2C::SetContinuedMode()
{
	I2C::ContinuedMode = true;
}

void I2C::SetNonContinuedMode()
{
	I2C::ContinuedMode = false;
}

void I2C::ConfigureClock1()
{
	HWREG(SOC_PRCM_REGS + CM_PER_L3S_CLKSTCTRL) |=
		CM_PER_L3S_CLKSTCTRL_CLKTRCTRL_SW_WKUP;

	while ((HWREG(SOC_PRCM_REGS + CM_PER_L3S_CLKSTCTRL) &
		CM_PER_L3S_CLKSTCTRL_CLKTRCTRL) != CM_PER_L3S_CLKSTCTRL_CLKTRCTRL_SW_WKUP);

	HWREG(SOC_PRCM_REGS + CM_PER_L3_CLKSTCTRL) |=
		CM_PER_L3_CLKSTCTRL_CLKTRCTRL_SW_WKUP;

	while ((HWREG(SOC_PRCM_REGS + CM_PER_L3_CLKSTCTRL) &
		CM_PER_L3_CLKSTCTRL_CLKTRCTRL) != CM_PER_L3_CLKSTCTRL_CLKTRCTRL_SW_WKUP);

	HWREG(SOC_PRCM_REGS + CM_PER_L3_INSTR_CLKCTRL) |=
		CM_PER_L3_INSTR_CLKCTRL_MODULEMODE_ENABLE;

	while ((HWREG(SOC_PRCM_REGS + CM_PER_L3_INSTR_CLKCTRL) &
		CM_PER_L3_INSTR_CLKCTRL_MODULEMODE) !=
		CM_PER_L3_INSTR_CLKCTRL_MODULEMODE_ENABLE);

	HWREG(SOC_PRCM_REGS + CM_PER_L3_CLKCTRL) |=
		CM_PER_L3_CLKCTRL_MODULEMODE_ENABLE;

	while ((HWREG(SOC_PRCM_REGS + CM_PER_L3_CLKCTRL) &
		CM_PER_L3_CLKCTRL_MODULEMODE) != CM_PER_L3_CLKCTRL_MODULEMODE_ENABLE);

	HWREG(SOC_PRCM_REGS + CM_PER_OCPWP_L3_CLKSTCTRL) |=
		CM_PER_OCPWP_L3_CLKSTCTRL_CLKTRCTRL_SW_WKUP;

	while ((HWREG(SOC_PRCM_REGS + CM_PER_OCPWP_L3_CLKSTCTRL) &
		CM_PER_OCPWP_L3_CLKSTCTRL_CLKTRCTRL) !=
		CM_PER_OCPWP_L3_CLKSTCTRL_CLKTRCTRL_SW_WKUP);

	HWREG(SOC_PRCM_REGS + CM_PER_L4LS_CLKSTCTRL) |=
		CM_PER_L4LS_CLKSTCTRL_CLKTRCTRL_SW_WKUP;

	while ((HWREG(SOC_PRCM_REGS + CM_PER_L4LS_CLKSTCTRL) &
		CM_PER_L4LS_CLKSTCTRL_CLKTRCTRL) !=
		CM_PER_L4LS_CLKSTCTRL_CLKTRCTRL_SW_WKUP);

	HWREG(SOC_PRCM_REGS + CM_PER_L4LS_CLKCTRL) |=
		CM_PER_L4LS_CLKCTRL_MODULEMODE_ENABLE;

	while ((HWREG(SOC_PRCM_REGS + CM_PER_L4LS_CLKCTRL) &
		CM_PER_L4LS_CLKCTRL_MODULEMODE) != CM_PER_L4LS_CLKCTRL_MODULEMODE_ENABLE);

	HWREG(SOC_PRCM_REGS + CM_PER_I2C1_CLKCTRL) |=
		CM_PER_I2C1_CLKCTRL_MODULEMODE_ENABLE;

	while ((HWREG(SOC_PRCM_REGS + CM_PER_I2C1_CLKCTRL) &
		CM_PER_I2C1_CLKCTRL_MODULEMODE) != CM_PER_I2C1_CLKCTRL_MODULEMODE_ENABLE);

	while (!(HWREG(SOC_PRCM_REGS + CM_PER_L3S_CLKSTCTRL) &
		CM_PER_L3S_CLKSTCTRL_CLKACTIVITY_L3S_GCLK));

	while (!(HWREG(SOC_PRCM_REGS + CM_PER_L3_CLKSTCTRL) &
		CM_PER_L3_CLKSTCTRL_CLKACTIVITY_L3_GCLK));

	while (!(HWREG(SOC_PRCM_REGS + CM_PER_OCPWP_L3_CLKSTCTRL) &
		(CM_PER_OCPWP_L3_CLKSTCTRL_CLKACTIVITY_OCPWP_L3_GCLK |
		CM_PER_OCPWP_L3_CLKSTCTRL_CLKACTIVITY_OCPWP_L4_GCLK)));

	while (!(HWREG(SOC_PRCM_REGS + CM_PER_L4LS_CLKSTCTRL) &
		(CM_PER_L4LS_CLKSTCTRL_CLKACTIVITY_L4LS_GCLK |
		CM_PER_L4LS_CLKSTCTRL_CLKACTIVITY_I2C_FCLK)));
}

void I2C::ConfigureClock2()
{
	HWREG(SOC_PRCM_REGS + CM_PER_L3S_CLKSTCTRL) |=
		CM_PER_L3S_CLKSTCTRL_CLKTRCTRL_SW_WKUP;

	while ((HWREG(SOC_PRCM_REGS + CM_PER_L3S_CLKSTCTRL) &
		CM_PER_L3S_CLKSTCTRL_CLKTRCTRL) != CM_PER_L3S_CLKSTCTRL_CLKTRCTRL_SW_WKUP);

	HWREG(SOC_PRCM_REGS + CM_PER_L3_CLKSTCTRL) |=
		CM_PER_L3_CLKSTCTRL_CLKTRCTRL_SW_WKUP;

	while ((HWREG(SOC_PRCM_REGS + CM_PER_L3_CLKSTCTRL) &
		CM_PER_L3_CLKSTCTRL_CLKTRCTRL) != CM_PER_L3_CLKSTCTRL_CLKTRCTRL_SW_WKUP);

	HWREG(SOC_PRCM_REGS + CM_PER_L3_INSTR_CLKCTRL) |=
		CM_PER_L3_INSTR_CLKCTRL_MODULEMODE_ENABLE;

	while ((HWREG(SOC_PRCM_REGS + CM_PER_L3_INSTR_CLKCTRL) &
		CM_PER_L3_INSTR_CLKCTRL_MODULEMODE) !=
		CM_PER_L3_INSTR_CLKCTRL_MODULEMODE_ENABLE);

	HWREG(SOC_PRCM_REGS + CM_PER_L3_CLKCTRL) |=
		CM_PER_L3_CLKCTRL_MODULEMODE_ENABLE;

	while ((HWREG(SOC_PRCM_REGS + CM_PER_L3_CLKCTRL) &
		CM_PER_L3_CLKCTRL_MODULEMODE) != CM_PER_L3_CLKCTRL_MODULEMODE_ENABLE);

	HWREG(SOC_PRCM_REGS + CM_PER_OCPWP_L3_CLKSTCTRL) |=
		CM_PER_OCPWP_L3_CLKSTCTRL_CLKTRCTRL_SW_WKUP;

	while ((HWREG(SOC_PRCM_REGS + CM_PER_OCPWP_L3_CLKSTCTRL) &
		CM_PER_OCPWP_L3_CLKSTCTRL_CLKTRCTRL) !=
		CM_PER_OCPWP_L3_CLKSTCTRL_CLKTRCTRL_SW_WKUP);

	HWREG(SOC_PRCM_REGS + CM_PER_L4LS_CLKSTCTRL) |=
		CM_PER_L4LS_CLKSTCTRL_CLKTRCTRL_SW_WKUP;

	while ((HWREG(SOC_PRCM_REGS + CM_PER_L4LS_CLKSTCTRL) &
		CM_PER_L4LS_CLKSTCTRL_CLKTRCTRL) !=
		CM_PER_L4LS_CLKSTCTRL_CLKTRCTRL_SW_WKUP);

	HWREG(SOC_PRCM_REGS + CM_PER_L4LS_CLKCTRL) |=
		CM_PER_L4LS_CLKCTRL_MODULEMODE_ENABLE;

	while ((HWREG(SOC_PRCM_REGS + CM_PER_L4LS_CLKCTRL) &
		CM_PER_L4LS_CLKCTRL_MODULEMODE) != CM_PER_L4LS_CLKCTRL_MODULEMODE_ENABLE);

	HWREG(SOC_PRCM_REGS + CM_PER_I2C2_CLKCTRL) |=
		CM_PER_I2C2_CLKCTRL_MODULEMODE_ENABLE;

	while ((HWREG(SOC_PRCM_REGS + CM_PER_I2C2_CLKCTRL) &
		CM_PER_I2C2_CLKCTRL_MODULEMODE) != CM_PER_I2C2_CLKCTRL_MODULEMODE_ENABLE);

	while (!(HWREG(SOC_PRCM_REGS + CM_PER_L3S_CLKSTCTRL) &
		CM_PER_L3S_CLKSTCTRL_CLKACTIVITY_L3S_GCLK));

	while (!(HWREG(SOC_PRCM_REGS + CM_PER_L3_CLKSTCTRL) &
		CM_PER_L3_CLKSTCTRL_CLKACTIVITY_L3_GCLK));

	while (!(HWREG(SOC_PRCM_REGS + CM_PER_OCPWP_L3_CLKSTCTRL) &
		(CM_PER_OCPWP_L3_CLKSTCTRL_CLKACTIVITY_OCPWP_L3_GCLK |
		CM_PER_OCPWP_L3_CLKSTCTRL_CLKACTIVITY_OCPWP_L4_GCLK)));

	while (!(HWREG(SOC_PRCM_REGS + CM_PER_L4LS_CLKSTCTRL) &
		(CM_PER_L4LS_CLKSTCTRL_CLKACTIVITY_L4LS_GCLK |
		CM_PER_L4LS_CLKSTCTRL_CLKACTIVITY_I2C_FCLK)));
}