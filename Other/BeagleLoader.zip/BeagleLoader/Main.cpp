#include "soc_AM335x.h"
#include "beaglebone.h"
#include "gpio_v2.h"

#include "Log.h"
#include "Hardware.h"
#include "GPIO.h"
#include "Component.h"
#include "Bootloader.h"
#include "UART.h"
#include "Updater.h"
#include "WheelSpeed.h"
#include "I2C.h"
#include "Encoder.h"

#include "interrupt.h"
#include "hw_control_AM335x.h"
#include "pin_mux.h"
#include "uart_irda_cir.h"
#include "tsc_adc.h"

#include <stdlib.h>

static unsigned char bootMode = 0; //0 for not set, 1 for update, 2 for model

static void tickHandler();
static void HardwareTestSetup();
static void RequestBootMode();

extern const unsigned int ModelRegion_Start;
EntryVectors vectors;
volatile int delay_count = 0;
volatile bool timer_tick = false;
volatile char iterations = 0;

int main()
{
	Bootloader::Bootload();

	Hardware::Start();
	//UART::InterruptEnable();

	//RequestBootMode();
	
	//continue as before

	I2C::Start(I2C_Module1, IMU::AccelMagAddress);
	I2C::Start(I2C_Module2, 0x6B);
	WheelSpeed::Setup();

	IMU::ConfigureIMU();
	IMU::GetAccelerometerData();
	IMU::GetGyroscopeData();
	//IMU::GetMagnetometerData();
	Encoder::ReadValues();
	Log::Trace("%d %d %d %d", Encoder::Values.Position, Encoder::Values.LeftGearPosition, Encoder::Values.RightGearPosition, Encoder::Values.Temperature);
	
	vectors.SimulationSetup();
	Log::Trace("Model setup");
	IMU::WritePayloadToModel();
	Encoder::WritePayloadToModel();
	Log::Info("Model executing @ %u Hz", 1000);

	Hardware::SetupProcessorTick(1000, tickHandler);



	

	while (true)
	{
		 if (timer_tick) {
			//Log::Info("tick start");
			IMU::GetAccelerometerData();
			Log::Info("Accel");
			//Log::Info("%d", iterations);
			IMU::GetMagnetometerData();
			Log::Info("Mag");
			//Log::Info("%d", iterations);
			//IMU::GetGyroscopeData();
			//Log::Info("Gyro");
			//Log::Info("%d", iterations);
			//Encoder::ReadValues();
			//Log::Info("Encoder");
			//Log::Info("%d", iterations);
			//Log::Info("tick end");
			timer_tick = false;
			//iterations++; 
		}
		__asm volatile("NOP");
	}

	return 0;
}

static void tickHandler()
{	
	ResetTimer(SOC_DMTIMER_2_REGS);
	timer_tick = true;

	//Log::Info("test");
	//Log::Info("Timer Start");
	WheelSpeed::counter++;
	//Write latest sensor values and serial data to model
	//UART::WritePayloadToModel();
	WheelSpeed::WritePayloadToModel();
	vectors.SimulationStep();
	//iterations++;
	//Log::Info("Timer End");
}

static void RequestBootMode() {
	Log::Trace("Requesting boot mode");
	int retries = 0;
	while (!bootMode && retries < 10) {
		bootMode = Updater::RequestBootMode();
		retries++;
	} 
	Log::Info("Received response");
	if (bootMode == 1) {
		Log::Trace("Booting to update mode");
		Updater::EnterUpdateMode();
	} else if (bootMode == 2) {
		Log::Trace("Booting to simulation mode");
	}
}
// Old main
//GPIO::Set(Component::SteeringAEnable, false);
//GPIO::Set(Component::SteeringBEnable, false);
//GPIO::Set(Component::ClutchEnableInput, false);
//GPIO::Set(Component::LeftGearEnableInput, false);
//GPIO::Set(Component::RightGearEnableInput, false);
//GPIO::Set(Component::BrakeEnableInput, false);
//
//GPIO::Set(Component::ClutchPower1, false);
//GPIO::Set(Component::ClutchPower2, false);
//GPIO::Set(Component::LED1, on);
// Old Tick
//GPIO::Set(Component::SteeringBPower, false);
//GPIO::Set(Component::ClutchPower1, false);
//GPIO::Set(Component::LeftGearPower1, false);
//GPIO::Set(Component::RightGearPower1, false);
//GPIO::Set(Component::BrakePower1, false);
//GPIO::Set(Component::SteeringAPower, false);
//GPIO::Set(Component::ClutchPower2, false);
//GPIO::Set(Component::LeftGearPower2, false);
//GPIO::Set(Component::RightGearPower2, false);
//GPIO::Set(Component::BrakePower2, false);
//for (int i = 0; i < 1000; i++)
//{
//	__asm volatile("NOP");
//}
//// STEERING POWER B
//GPIO::Set(Component::SteeringBPower, !on);
//GPIO::Set(Component::ClutchPower1, !on);
//GPIO::Set(Component::LeftGearPower1, !on);
//GPIO::Set(Component::RightGearPower1, !on);
//GPIO::Set(Component::BrakePower1, !on);
//// STEERING POWER A
//GPIO::Set(Component::SteeringAPower, on);
//GPIO::Set(Component::ClutchPower2, on);
//GPIO::Set(Component::LeftGearPower2, on);
//GPIO::Set(Component::RightGearPower2, on);
//GPIO::Set(Component::BrakePower2, on);
/*on = !on;*/
void HardwareTestSetup()
{
	// LEDs
	GPIO::AssignPin(Component::LED0, 1, 21, PAD_FS_RXD_PD_PUPDE(7));
	GPIO::AssignPin(Component::LED1, 1, 22, PAD_FS_RXD_PD_PUPDE(7));
	GPIO::AssignPin(Component::LED2, 1, 23, PAD_FS_RXD_PD_PUPDE(7));
	GPIO::AssignPin(Component::LED3, 1, 24, PAD_FS_RXD_PD_PUPDE(7));

	// Steering A
	GPIO::AssignPin(Component::SteeringAEnable, 0, 8, PAD_FS_RXD_PD_PUPDE(7));
	GPIO::AssignPin(Component::SteeringAPower, 0, 27, PAD_FS_RXD_PD_PUPDE(7));

	// Steering B
	GPIO::AssignPin(Component::SteeringBEnable, 2, 14, PAD_FS_RXD_PD_PUPDE(7));
	GPIO::AssignPin(Component::SteeringBPower, 2, 16, PAD_FS_RXD_PD_PUPDE(7));

	// Right Gear
	GPIO::AssignPin(Component::RightGearPower1, 2, 1, PAD_FS_RXD_PD_PUPDE(7));
	GPIO::AssignPin(Component::RightGearPower2, 1, 15, PAD_FS_RXD_PD_PUPDE(7));
	GPIO::AssignPin(Component::RightGearEnableInput, 2, 13, PAD_FS_RXD_PD_PUPDE(7));
	GPIO::AssignPin(Component::RightGearDisable, 2, 12, PAD_FS_RXD_PD_PUPDE(7));
	GPIO::AssignPin(Component::RightGearStatus, 2, 24, PAD_FS_RXE_PU_PUPDE(7));

	// Left Gear
	GPIO::AssignPin(Component::LeftGearPower1, 2, 23, PAD_FS_RXD_PD_PUPDE(7));
	GPIO::AssignPin(Component::LeftGearPower2, 2, 22, PAD_FS_RXD_PD_PUPDE(7));
	GPIO::AssignPin(Component::LeftGearEnableInput, 2, 8, PAD_FS_RXD_PD_PUPDE(7));
	GPIO::AssignPin(Component::LeftGearDisable, 2, 11, PAD_FS_RXD_PD_PUPDE(7));
	GPIO::AssignPin(Component::LeftGearStatus, 2, 17, PAD_FS_RXE_PU_PUPDE(7));

	// Clutch
	GPIO::AssignPin(Component::ClutchPower1, 2, 4, PAD_FS_RXD_PD_PUPDE(7));
	GPIO::AssignPin(Component::ClutchPower2, 2, 25, PAD_FS_RXD_PD_PUPDE(7));
	GPIO::AssignPin(Component::ClutchEnableInput, 1, 12, PAD_FS_RXD_PD_PUPDE(7));
	GPIO::AssignPin(Component::ClutchDisable, 0, 23, PAD_FS_RXD_PD_PUPDE(7));
	GPIO::AssignPin(Component::ClutchStatus, 2, 3, PAD_FS_RXE_PU_PUPDE(7));

	// Brake
	GPIO::AssignPin(Component::BrakePower1, 1, 13, PAD_FS_RXD_PD_PUPDE(7));
	GPIO::AssignPin(Component::BrakePower2, 0, 26, PAD_FS_RXD_PD_PUPDE(7));
	GPIO::AssignPin(Component::BrakeEnableInput, 2, 6, PAD_FS_RXD_PD_PUPDE(7));
	GPIO::AssignPin(Component::BrakeDisable, 2, 9, PAD_FS_RXD_PD_PUPDE(7));
	GPIO::AssignPin(Component::BrakeStatus, 1, 14, PAD_FS_RXE_PU_PUPDE(7));
}
