#include "IMU.h"
#include "I2C.h"
#include "Log.h"
#include "hsi2c.h"
#include "soc_AM335x.h"
#include "uartStdio.h"
#include "consoleUtils.h"
#include "climits"
#include "hw_uart_irda_cir.h"
#include "hw_types.h"
#include "uart_irda_cir.h"
#include "Bootloader.h"

IMU::IMU()
{
}


IMU::~IMU()
{
}

IMU::DataSet IMU::Accelerometer;
IMU::DataSet IMU::Gyroscope;
IMU::DataSet IMU::Magnetometer;

void IMU::ConfigureIMU()
{
	//Log::Trace("Configure IMU");
	// Enable the accelerometer
	IMU::Write(IMU::AccelMagAddress, MAGACCL_CTRL_REG1, 0b01100111);
	IMU::Write(IMU::GyroAddress, GYRO_CTRL_REG1, 0x0F);
	IMU::Write(IMU::GyroAddress, GYRO_CTRL_REG4, 0x00);

	IMU::Write(IMU::AccelMagAddress, MAGACCL_CTRL_REG5, 0b01110100);	

	IMU::Write(IMU::AccelMagAddress, MAGACCL_CTRL_REG7, 0x00);
	Log::Info("IMU Configured");

}

IMU::DataSet* IMU::GetAccelerometerData()
{
	Accelerometer.XAxis = IMU::Read(IMU::AccelMagAddress, ACCL_X_L);
	Accelerometer.XAxis |= IMU::Read(IMU::AccelMagAddress, ACCL_X_H) << 8;

	Accelerometer.YAxis = IMU::Read(IMU::AccelMagAddress, ACCL_Y_L);
	Accelerometer.YAxis |= IMU::Read(IMU::AccelMagAddress, ACCL_Y_H) << 8;

	Accelerometer.ZAxis = IMU::Read(IMU::AccelMagAddress, ACCL_Z_L);
	Accelerometer.ZAxis |= IMU::Read(IMU::AccelMagAddress, ACCL_Z_H) << 8;

	//int zsign = Accelerometer.ZAxis & 0b1000000000000000;
	//Accelerometer.ZAxis &= 0b0111111111111111;
	//Accelerometer.ZAxis *= (zsign > 0) ? -1 : 1;
	Accelerometer.XAxis *= 1000 * (2.0 / 32768.0f);
	Accelerometer.YAxis *= 1000 * (2.0 / 32768.0f);
	Accelerometer.ZAxis *= 1000 * (2.0 / 32768.0f);
	return &Accelerometer;
}

IMU::DataSet* IMU::GetGyroscopeData()
{
	Gyroscope.XAxis = IMU::Read(IMU::GyroAddress, GYRO_X_L);
	Gyroscope.XAxis |= IMU::Read(IMU::GyroAddress, GYRO_X_H) << 8;

	Gyroscope.YAxis = IMU::Read(IMU::GyroAddress, GYRO_Y_L);
	Gyroscope.YAxis |= IMU::Read(IMU::GyroAddress, GYRO_Y_H) << 8;

	Gyroscope.ZAxis = IMU::Read(IMU::GyroAddress, GYRO_Z_L);
	Gyroscope.ZAxis |= IMU::Read(IMU::GyroAddress, GYRO_Z_H) << 8;

	return &Accelerometer;
}

IMU::DataSet* IMU::GetMagnetometerData()
{
	Magnetometer.XAxis = IMU::Read(IMU::AccelMagAddress, MAG_X_L);
	Magnetometer.XAxis |= IMU::Read(IMU::AccelMagAddress, MAG_X_H) << 8;

	Magnetometer.YAxis = IMU::Read(IMU::AccelMagAddress, MAG_Y_L);
	Magnetometer.YAxis |= IMU::Read(IMU::AccelMagAddress, MAG_Y_H) << 8;

	Magnetometer.ZAxis = IMU::Read(IMU::AccelMagAddress, MAG_Z_L);
	Magnetometer.ZAxis |= IMU::Read(IMU::AccelMagAddress, MAG_Z_H) << 8;

	Magnetometer.XAxis *= 1000 * 2 / 32768.0f;
	Magnetometer.YAxis *= 1000 * 2 / 32768.0f;
	Magnetometer.ZAxis *= 1000 * 2 / 32768.0f;

	return &Accelerometer;
}

unsigned char IMU::GetGyroAddress()
{
	return IMU::Read(IMU::GyroAddress, 0xF);
}

unsigned char IMU::GetAccelAddress()
{
	return IMU::Read(IMU::AccelMagAddress, 0xF);
}

unsigned char IMU::Read(unsigned char address, unsigned char subAddress)
{
	// Set up the transmit buffer
	I2C::TransmitBuffer[I2C_Module1].ExpectedBytes = 1;
	// Set the sub address to the first transmitted byte
	I2C::TransmitBuffer[I2C_Module1].Data[0] = subAddress;

	// Set the main slave address
	I2C::SetSlaveAddress(I2C_Module1, address);

	// Set continued mode to disable an I2C stop condition after each read/write operation
	I2C::SetContinuedMode();
	// Write the slave address, and the sub address
	I2C::Write(I2C_Module1);
	// Read the value from the slave, NMAK and STOP
	I2C::SetNonContinuedMode();
	I2C::SetSlaveAddress(I2C_Module1, address);
	I2C::Read(I2C_Module1, 1);
	return I2C::ReceiveBuffer[I2C_Module1].Data[0];
}

bool IMU::CommunicationCheck()
{
	return GetGyroAddress() == GyroWhoAmI && GetAccelAddress() == AccelMagWhoAmI;
}

bool IMU::Write(unsigned char address, unsigned char subAddress, unsigned char value)
{
	//Log::Trace("IMU WRITE %x", address);
	// Set up the transmit buffer
	I2C::TransmitBuffer[I2C_Module1].ExpectedBytes = 2;
	// Set the sub address to the first transmitted byte
	I2C::TransmitBuffer[I2C_Module1].Data[0] = subAddress;
	I2C::TransmitBuffer[I2C_Module1].Data[1] = value;

	// Set the main slave address
	I2C::SetSlaveAddress(I2C_Module1, address);

	// Set continued mode to disable an I2C stop condition after each read/write operation
	I2C::SetNonContinuedMode();

	// Write the slave address, and the sub address
	I2C::Write(I2C_Module1);

	return true;
}

bool IMU::Write(unsigned char address, unsigned char subAddress, unsigned char* values, unsigned char count)
{

	return 0;
}

void IMU::WritePayloadToModel() {
	vectors.UpdateIMUValues(&(IMU::Accelerometer), &(IMU::Gyroscope), &(IMU::Magnetometer));
}
