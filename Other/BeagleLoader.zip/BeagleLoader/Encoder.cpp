#include "Log.h"
#include "Encoder.h"
#include "I2C.h"
#include "Bootloader.h"

Encoder::EncoderValues Encoder::Values;
bool Encoder::ISR = false;

Encoder::Encoder()
{
}


Encoder::~Encoder()
{
}

void Encoder::ReadValues()
{
	I2C::Read(I2C_Module2, 4);

	Encoder::Values.Position = (signed char)greyToBinary(~I2C::ReceiveBuffer[I2C_Module2].Data[0]);
	Encoder::Values.LeftGearPosition = (I2C::ReceiveBuffer[I2C_Module2].Data[1] << 2)
		| ((I2C::ReceiveBuffer[I2C_Module2].Data[2] & 0xC0) >> 6);
	Encoder::Values.RightGearPosition = ((I2C::ReceiveBuffer[I2C_Module2].Data[2] & 0x3F) << 4)
		| ((I2C::ReceiveBuffer[I2C_Module2].Data[3] & 0xF0) >> 4);
	Encoder::Values.Temperature = (I2C::ReceiveBuffer[I2C_Module2].Data[3] & 0x0F);
	Encoder::ISR = false;
}

void Encoder::WritePayloadToModel()
{
	vectors.UpdateEncoderValues(&Encoder::Values);
}

unsigned char greyToBinary(unsigned char grey) {
	unsigned char mask;
    for (mask = grey >> 1; mask != 0; mask = mask >> 1)
    {
        grey = grey ^ mask;
    }
    return grey;
}

unsigned char reverseChar(unsigned char byte) {
	unsigned char reversed = 0;
	for (int i = 0; i < 8; i++) {
		reversed |= ((byte >> i & 0x01) << (7 - i));
	}
	return reversed;
}
