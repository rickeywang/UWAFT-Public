#include "WheelSpeed.h"
#include "GPIO.h"
//#include "Pad.h"
#include "Component.h"
#include "gpio_v2.h"
#include "Log.h"
#include "interrupt.h"
#include "pin_mux.h"
#include "Bootloader.h"
#include <ctime>

float WheelSpeed::speed = 0;

unsigned int bank = 1;
unsigned int pin = 17;
double WheelSpeed::counter = 0;
unsigned int pulses = 0;
const double RADIUS = 0.508;

WheelSpeed::WheelSpeed()
{
}


WheelSpeed::~WheelSpeed()
{
}


void WheelSpeed::Setup()
{
	IntRegister(SYS_INT_GPIOINT1A, WheelSpeed::InterruptHandler);
	IntPrioritySet(SYS_INT_GPIOINT1A, 4, AINTC_HOSTINT_ROUTE_IRQ);
	IntSystemEnable(SYS_INT_GPIOINT1A);

	GPIO::AssignPin(Component::WheelSpeedPulse, bank, pin, PAD_FS_RXE_PU_PUPDE(7));
	Log::Info("Wheelspeed Muxed");
	GPIO::RegisterInterrupt(bank, pin, GPIO_INT_TYPE_RISE_EDGE);

	/* Interrupt configuration */
	
}

void WheelSpeed::InterruptHandler() {
	pulses++;
	if (pulses == 3) {
		WheelSpeed::speed = (RADIUS * 2.0 * 3.14) / 8.0 * 2.0 / (counter / 1000.0);
		//Log::Info("Speed: %u", (int)(WheelSpeed::speed * 100));
		WheelSpeed::counter = 0;
		pulses = 0;
	} 

	GPIOPinIntClear(GPIO::GPIOControlRegisters[bank], GPIO_INT_LINE_1, pin);
}

double WheelSpeed::CalculateSpeed() {
	WheelSpeed::speed = ((0.058 * 2.0 * 3.14) / 8.0) * (pulses) / 0.5;
	pulses = 0;
	return WheelSpeed::speed;
}

void WheelSpeed::WritePayloadToModel() {
	vectors.SetWheelSpeed((double)speed);
}