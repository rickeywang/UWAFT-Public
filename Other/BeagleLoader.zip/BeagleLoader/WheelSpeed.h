#pragma once
class WheelSpeed
{
public:
	WheelSpeed();
	~WheelSpeed();
	static void Setup();
	static void InterruptHandler();
	static double CalculateSpeed();
	static void WritePayloadToModel();
	static double counter;
	static float speed;
};

