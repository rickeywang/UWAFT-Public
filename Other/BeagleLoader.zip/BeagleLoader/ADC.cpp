#include "ADC.h"
#include "Log.h"
#include "Bootloader.h"

#include "tsc_adc.h"
#include "soc_AM335x.h"
#include "hw_control_AM335x.h"
#include "hw_cm_wkup.h"
#include "interrupt.h"

ADC::ADC()
{
}

ADC::~ADC()
{
}

void ADC::ADCInterrupt()
{
	//Log::Info("Interrupt");
	vectors.ADCInterrupt();
}